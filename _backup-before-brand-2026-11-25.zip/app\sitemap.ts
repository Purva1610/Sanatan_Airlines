import type { MetadataRoute } from 'next';
import { airlineRoutes, noIndexRoutes, publicRoutes } from '../src/seo.js';
import { getConfiguredSiteOrigin } from '../src/siteConfig.js';

export default function sitemap(): MetadataRoute.Sitemap {
  const origin = getConfiguredSiteOrigin();
  if (!origin) return [];

  return [...publicRoutes, ...airlineRoutes]
    .filter((route) => !noIndexRoutes.includes(route))
    .map((route) => ({
      url: `${origin}${route === '/' ? '' : route}`,
      changeFrequency: 'monthly' as const,
      priority: route === '/' ? 1 : 0.7,
    }));
}
