import AviationDisclaimerPage from '../../src/airline/legalPages/AviationDisclaimer';
import PageSkin from '../../src/PageSkin.jsx';

export const metadata = {
  title: 'Aviation Disclaimer | Sanatan Airlines',
  description: 'Regulatory compliance notices, safety obligations and liability limitations applicable to all Sanatan Airlines operations.',
};

export default function Page() {
  return <PageSkin route="/aviation-disclaimer"><AviationDisclaimerPage /></PageSkin>;
}
