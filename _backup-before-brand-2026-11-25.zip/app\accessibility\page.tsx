import AccessibilityStatementPage from '../../src/airline/legalPages/AccessibilityStatement';
import PageSkin from '../../src/PageSkin.jsx';

export const metadata = {
  title: 'Accessibility Statement | Sanatan Airlines',
  description: 'Sanatan Airlines\' commitment to WCAG 2.1 AA digital accessibility and physical accessibility for passengers with disabilities.',
};

export default function Page() {
  return <PageSkin route="/accessibility"><AccessibilityStatementPage /></PageSkin>;
}
