'use client';
import { AlertTriangle } from 'lucide-react';
import Link from 'next/link';
import { useI18n } from './i18n/I18nContext.jsx';
import { AirlineFooter } from './AirlineFooter.jsx';
import LanguageSwitcher from './LanguageSwitcher.jsx';

function LegalHeader() {
  const { t } = useI18n();
  return (
    <header style={{
      background: '#0504aa',
      position: 'sticky', top: 0, zIndex: 100,
      boxShadow: '0 2px 12px rgba(0,0,0,0.12)',
    }}>
      <div className="al-container" style={{ height: 68, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Link href="/airline" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
          <span style={{ width: 36, height: 36, borderRadius: '50%', background: '#ff4800', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 15, color: '#fff' }}>SA</span>
          <span style={{ color: '#fff', fontSize: 13, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
            SANATAN <small style={{ fontSize: 9, opacity: 0.65 }}>AIRLINES</small>
          </span>
        </Link>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <Link href="/airline" style={{ color: 'rgba(255,255,255,0.8)', fontSize: 13, textDecoration: 'none' }}>← {t('footer.about') || 'Home'}</Link>
          <LanguageSwitcher />
        </div>
      </div>
    </header>
  );
}

export function LegalPageLayout({ children, title, lastUpdated }) {
  const { t } = useI18n();
  return (
    <>
      <LegalHeader />
      <main>
        {/* Hero strip */}
        <div style={{
          background: 'linear-gradient(135deg, #04036b 0%, #0504aa 100%)',
          padding: '52px 24px 48px',
        }}>
          <div className="al-container">
            {/* Breadcrumb */}
            <nav style={{ fontSize: 13, color: 'rgba(215,242,250,0.6)', marginBottom: 20, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <Link href="/airline" style={{ color: 'rgba(215,242,250,0.6)', textDecoration: 'none' }}>Home</Link>
              <span>›</span>
              <span style={{ color: 'rgba(215,242,250,0.9)' }}>{title}</span>
            </nav>
            <h1 style={{ fontFamily: "'Playfair Display', Georgia, serif", fontSize: 'clamp(26px,4vw,44px)', fontWeight: 700, color: '#fff', lineHeight: 1.15, marginBottom: 14 }}>
              {title}
            </h1>
            {lastUpdated && (
              <p style={{ fontSize: 13, color: 'rgba(215,242,250,0.55)' }}>
                {t('legal.lastUpdated') || 'Last Updated'}: <strong style={{ color: 'rgba(215,242,250,0.8)' }}>{lastUpdated}</strong>
              </p>
            )}
          </div>
        </div>

        {/* Review note */}
        <div style={{ background: '#fff8e6', borderBottom: '2px solid #f59e0b', padding: '14px 24px' }}>
          <div className="al-container" style={{ fontSize: 13, color: '#92400e', fontWeight: 600 }}>
            {t('legal.reviewNote') || '<AlertTriangle size={20}/> This document is prepared for legal review before publication. Please consult qualified legal counsel before making it publicly available.'}
          </div>
        </div>

        {/* Content */}
        <article style={{
          maxWidth: 820,
          margin: '0 auto',
          padding: '64px 24px 80px',
          fontFamily: 'var(--al-body-font, Manrope, sans-serif)',
          color: '#1a1a3e',
          lineHeight: 1.8,
          fontSize: 15,
        }}>
          {children}
          {/* Contact for legal queries */}
          <div style={{ marginTop: 48, padding: '24px 28px', background: '#f8f9fa', borderRadius: 10, border: '1.5px solid #e2e8f0' }}>
            <p style={{ fontSize: 14, color: '#64748b', margin: 0 }}>
              {t('legal.contact') || 'For queries regarding this policy, write to'}{' '}
              <a href="mailto:legal@sanatanairlines.com" style={{ color: '#0504aa', fontWeight: 700 }}>legal@sanatanairlines.com</a>
              {' '}or call <a href="tel:+911800123456" style={{ color: '#0504aa', fontWeight: 700 }}>1800 123 4567</a>.
            </p>
          </div>
        </article>
      </main>
      <AirlineFooter />
    </>
  );
}

/** Wrap legal page — I18nProvider is global, just render children */
export function LegalPage({ title, lastUpdated, children }) {
  return (
    <LegalPageLayout title={title} lastUpdated={lastUpdated}>
      {children}
    </LegalPageLayout>
  );
}
