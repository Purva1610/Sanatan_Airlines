'use client';

import { useEffect } from 'react';
import { usePathname } from 'next/navigation';

const CARD_SELECTOR = [
  '.quick-option',
  '.pillar-card',
  '.aviation-card',
  '.aviation-index-grid > a',
  '.aviation-related-grid > a',
  '.aviation-process-grid > article',
  '.aviation-use-list > li',
  '.global-mosaic > a',
  '.global-related-grid > a',
  '.global-type-grid > article',
  '.global-use-cases > ul > li',
  '.club-inclusion-grid > article',
  '.club-process-grid > *',
  '.franchise-profile-grid > *',
  '.franchise-investment-card',
  '.franchise-support-grid > *',
  '.corporate-sections > article',
  '.destination-results > article',
  '.insight-card',
  '.plan-card',
  '.process-step',
  '.why-item',
].join(',');

const EASE = 'cubic-bezier(0.2, 0.75, 0.3, 1)';

const ENTRANCE_SELECTOR = [
  '.hero-copy > *',
  '.club-hero-copy > *',
  '.aviation-service-hero-copy > *',
  '.global-service-hero-copy > *',
  '.franchise-hero-copy > *',
  '.hero-visual',
  '.club-hero-image',
  '.aviation-service-hero-visual',
  '.global-service-hero-image',
  '.franchise-hero-image',
].join(',');

// Areas the premium layer must leave untouched (About section / About pages).
const PROTECTED_SELECTOR = '.sa-about, .premium-keep';

const HERO_SELECTOR = '.sa-hero, .al-hero, .sa-m-hero, .sa-y-hero, .sa-av-hero, .hero, .club-hero, .aviation-service-hero, .global-service-hero, .franchise-hero';

const PARALLAX_SELECTOR = '.sa-hero-media, .al-hero-bg, .sa-m-hero-media, .sa-av-hero-media';

const SPOTLIGHT_SELECTOR = [
  '.sa-pillar-card', '.sa-quick-card', '.sa-insight-card', '.al-card', '.scs-step-card',
  '.scs-pillar-card', '.scs-value-card', '.aviation-index-card', '.aviation-related-card',
  '.club-inclusion-card', '.plan-card', '.insight-card', '.franchise-investment-card', '.sa-form-card',
  '.sa-region',
].join(',');

// Card families on skinned pages (airline + sub-sites).
const SKIN_CARD_SELECTOR = [
  '.al-card', '.al-amenity', '.al-dest-card', '.al-gallery-img', '.al-desc-img',
  '.scs-step-card', '.scs-pillar-card', '.scs-value-card', '.club-inclusion-card',
  '.aviation-index-card', '.aviation-related-card', '.global-mosaic-card', '.sa-m-dest-tile',
].join(',');

// Card families on the home page (the About section is excluded at runtime).
const HOME_CARD_SELECTOR = [
  '.sa-pillar-card', '.sa-quick-card', '.sa-insight-card', '.sa-region',
  '.scs-pillar-card', '.scs-step-card', '.scs-value-card',
].join(',');

// Per-skin entrance styles for content blocks / cards.
const BLOCK_FRAMES = {
  base: [{ opacity: 0, transform: 'translateY(18px)' }, { opacity: 1, transform: 'translateY(0)' }],
  rise: [{ opacity: 0, transform: 'translateY(48px)' }, { opacity: 1, transform: 'none' }],
  blur: [{ opacity: 0, filter: 'blur(14px)', transform: 'translateY(16px)' }, { opacity: 1, filter: 'blur(0)', transform: 'none' }],
  mask: [{ opacity: 0, clipPath: 'inset(0 0 100% 0)', transform: 'translateY(30px)' }, { opacity: 1, clipPath: 'inset(0 0 0% 0)', transform: 'none' }],
  zoom: [{ opacity: 0, transform: 'scale(0.88)' }, { opacity: 1, transform: 'none' }],
  flip: [{ opacity: 0, transform: 'perspective(900px) rotateX(22deg) translateY(40px)', transformOrigin: '50% 0' }, { opacity: 1, transform: 'perspective(900px) rotateX(0) translateY(0)', transformOrigin: '50% 0' }],
};

// Per-skin word styles for page titles and section headings.
const TITLE_FRAMES = {
  rise: [{ opacity: 0, transform: 'translateY(0.7em)' }, { opacity: 1, transform: 'none' }],
  blur: [{ opacity: 0, filter: 'blur(12px)' }, { opacity: 1, filter: 'blur(0)' }],
  mask: [{ opacity: 0, clipPath: 'inset(0 0 100% 0)', transform: 'translateY(0.5em)' }, { opacity: 1, clipPath: 'inset(0 0 0% 0)', transform: 'none' }],
  slide: [{ opacity: 0, transform: 'translateX(-0.6em)' }, { opacity: 1, transform: 'none' }],
  zoom: [{ opacity: 0, transform: 'scale(1.6)' }, { opacity: 1, transform: 'none' }],
  flip: [{ opacity: 0, transform: 'perspective(600px) rotateX(-80deg)', transformOrigin: '50% 100%' }, { opacity: 1, transform: 'perspective(600px) rotateX(0)', transformOrigin: '50% 100%' }],
};

const MAGNETIC_SELECTOR = '.al-btn-primary, .al-btn-secondary, .sa-btn, .button, .p-cta-book, .header-cta';

function canAnimate(el) {
  if (!el || el instanceof SVGElement) return false;
  if (el.matches('script, style, link, meta')) return false;
  if (el.matches(ENTRANCE_SELECTOR)) return false;
  if (el.classList.contains('reveal') || el.closest('.reveal')) return false;
  const position = window.getComputedStyle(el).position;
  if (position === 'sticky' || position === 'fixed') return false;
  return true;
}

function isBelowFold(el) {
  return el.getBoundingClientRect().top >= window.innerHeight;
}

function splitHeading(heading) {
  if (heading.dataset.motionWords === 'true') return [];
  const walker = document.createTreeWalker(heading, NodeFilter.SHOW_TEXT);
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  nodes.forEach((node) => {
    const text = node.nodeValue;
    if (!text || !text.trim()) return;
    const fragment = document.createDocumentFragment();
    text.split(/(\s+)/).forEach((part) => {
      if (!part) return;
      if (/^\s+$/.test(part)) {
        fragment.appendChild(document.createTextNode(' '));
        return;
      }
      const word = document.createElement('span');
      word.className = 'motion-word';
      word.textContent = part;
      fragment.appendChild(word);
    });
    node.parentNode.replaceChild(fragment, node);
  });
  heading.dataset.motionWords = 'true';
  return Array.from(heading.querySelectorAll('.motion-word'));
}

export default function SiteMotion() {
  const pathname = usePathname();

  useEffect(() => {
    if (typeof window === 'undefined' || !('IntersectionObserver' in window)) return undefined;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return undefined;
    if (typeof Element.prototype.animate !== 'function') return undefined;

    const seen = new Set();
    const hidden = [];

    const register = (el, index) => {
      if (seen.has(el) || !canAnimate(el) || !isBelowFold(el)) return;
      seen.add(el);
      el.style.opacity = '0';
      hidden.push([el, index]);
    };

    const cards = document.querySelectorAll(CARD_SELECTOR);
    cards.forEach((el) => {
      const index = Array.prototype.indexOf.call(el.parentElement.children, el);
      register(el, index);
    });

    // Skinned pages: also stagger the airline / sub-site card families.
    const skinRoot = document.querySelector('.skin');
    const isHome = Boolean(document.querySelector('.sa-page'));
    const enhanced = Boolean(skinRoot || isHome);
    const motion = skinRoot?.dataset.motion || (isHome ? 'mask' : 'base');
    // Protected areas (About) keep the original, base animation.
    const motionFor = (el) => (el.closest(PROTECTED_SELECTOR) ? 'base' : motion);
    const extraCards = skinRoot ? SKIN_CARD_SELECTOR : (isHome ? HOME_CARD_SELECTOR : null);
    if (extraCards) {
      document.querySelectorAll(extraCards).forEach((el) => {
        if (el.closest(PROTECTED_SELECTOR)) return;
        const index = Array.prototype.indexOf.call(el.parentElement.children, el);
        register(el, index);
      });
    }

    const blocks = document.querySelectorAll('main section > *');
    blocks.forEach((el) => {
      if (el.matches(CARD_SELECTOR) || el.querySelector(CARD_SELECTOR)) return;
      if (extraCards && !el.closest(PROTECTED_SELECTOR) && (el.matches(extraCards) || el.querySelector(extraCards))) return;
      register(el, 0);
    });

    // Skinned pages + home: word-by-word reveal of the page title on load.
    if (enhanced) {
      const title = document.querySelector('main h1, .skin > header + div h1');
      if (title && !title.closest(PROTECTED_SELECTOR)) {
        const words = splitHeading(title);
        words.forEach((word, index) => {
          word.animate(TITLE_FRAMES[motion] || TITLE_FRAMES.rise, {
            duration: 1000, delay: 120 + Math.min(index, 12) * 70, easing: EASE, fill: 'backwards',
          });
        });
      }
    }

    const wordHeadings = [];
    document.querySelectorAll('main h2').forEach((heading) => {
      if (!isBelowFold(heading)) return;
      const words = splitHeading(heading);
      if (words.length) wordHeadings.push([heading, words]);
    });

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        const record = hidden.find(([el]) => el === entry.target);
        if (record) {
          const m = motionFor(entry.target);
          const delay = Math.min(record[1], 6) * (m === 'base' ? 55 : 90);
          const frames = m === 'slide'
            ? [
              { opacity: 0, transform: `translateX(${record[1] % 2 ? 56 : -56}px)` },
              { opacity: 1, transform: 'none' },
            ]
            : (BLOCK_FRAMES[m] || BLOCK_FRAMES.base);
          const animation = entry.target.animate(
            frames,
            { duration: m === 'base' ? 620 : 950, delay, easing: EASE, fill: 'backwards' },
          );
          animation.onfinish = () => {
            entry.target.style.opacity = '';
          };
        }
        const headingRecord = wordHeadings.find(([el]) => el === entry.target);
        if (headingRecord) {
          const hm = motionFor(headingRecord[0]);
          headingRecord[1].forEach((word, index) => {
            word.animate(
              hm === 'base'
                ? [
                  { opacity: 0, transform: 'translateY(0.45em)' },
                  { opacity: 1, transform: 'translateY(0)' },
                ]
                : (TITLE_FRAMES[hm] || TITLE_FRAMES.rise),
              { duration: hm === 'base' ? 520 : 800, delay: Math.min(index, 10) * (hm === 'base' ? 32 : 55), easing: EASE, fill: 'backwards' },
            );
          });
        }
        observer.unobserve(entry.target);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -30px 0px' });

    hidden.forEach(([el]) => observer.observe(el));
    wordHeadings.forEach(([heading]) => observer.observe(heading));

    /* ---- Premium: image reveal (skips the protected About areas) ---- */
    const revealImages = [];
    document.querySelectorAll('main img').forEach((img) => {
      if (img.closest(PROTECTED_SELECTOR) || img.closest(HERO_SELECTOR)) return;
      if (seen.has(img) || !isBelowFold(img)) return;
      const rect = img.getBoundingClientRect();
      if (rect.width < 160 || rect.height < 120) return;
      revealImages.push(img);
    });
    const imageObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.animate(
          [
            { clipPath: 'inset(14% 10% 14% 10% round 24px)', transform: 'scale(1.14)', filter: 'saturate(0.6)' },
            { clipPath: 'inset(0% 0% 0% 0% round 0px)', transform: 'scale(1)', filter: 'saturate(1)' },
          ],
          { duration: 1300, easing: 'cubic-bezier(0.16, 1, 0.3, 1)', fill: 'backwards' },
        );
        imageObserver.unobserve(entry.target);
      });
    }, { threshold: 0.15 });
    revealImages.forEach((img) => imageObserver.observe(img));

    /* ---- Premium: scroll progress bar ---- */
    let progress = document.querySelector('.p-progress');
    if (!progress) {
      progress = document.createElement('div');
      progress.className = 'p-progress';
      progress.setAttribute('aria-hidden', 'true');
      document.body.appendChild(progress);
    }

    /* ---- Premium: subtle hero parallax (uses `translate`, leaving `transform`/`scale` free) ---- */
    const parallaxTargets = Array.from(document.querySelectorAll(PARALLAX_SELECTOR))
      .filter((el) => !el.closest(PROTECTED_SELECTOR));

    let ticking = false;
    const update = () => {
      ticking = false;
      const y = window.scrollY;
      const max = document.documentElement.scrollHeight - window.innerHeight;
      progress.style.transform = `scaleX(${max > 0 ? Math.min(y / max, 1) : 0})`;
      if (y < window.innerHeight * 1.2) {
        parallaxTargets.forEach((el) => { el.style.translate = `0 ${(y * 0.18).toFixed(1)}px`; });
      }
    };

    const onScroll = () => {
      document.documentElement.classList.toggle('is-scrolled', window.scrollY > 10);
      if (!ticking) { ticking = true; window.requestAnimationFrame(update); }
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });

    /* ---- Premium: cursor spotlight on cards ---- */
    let magnet = null;
    const releaseMagnet = () => {
      if (!magnet) return;
      magnet.style.translate = '';
      magnet = null;
    };
    const onPointerMove = (event) => {
      const target = event.target instanceof Element ? event.target : null;
      const card = target ? target.closest(SPOTLIGHT_SELECTOR) : null;
      if (card) {
        const rect = card.getBoundingClientRect();
        card.style.setProperty('--mx', `${event.clientX - rect.left}px`);
        card.style.setProperty('--my', `${event.clientY - rect.top}px`);
      }
      // Magnetic buttons (skinned pages only).
      const button = enhanced && target ? target.closest(MAGNETIC_SELECTOR) : null;
      if (button !== magnet) releaseMagnet();
      if (button && !button.closest(PROTECTED_SELECTOR)) {
        magnet = button;
        const rect = button.getBoundingClientRect();
        const dx = event.clientX - (rect.left + rect.width / 2);
        const dy = event.clientY - (rect.top + rect.height / 2);
        button.style.transition = 'translate 0.25s cubic-bezier(0.16, 1, 0.3, 1)';
        button.style.translate = `${(dx * 0.22).toFixed(1)}px ${(dy * 0.32).toFixed(1)}px`;
      }
    };
    const finePointer = window.matchMedia('(pointer: fine)').matches;
    if (finePointer) document.addEventListener('pointermove', onPointerMove, { passive: true });

    return () => {
      observer.disconnect();
      imageObserver.disconnect();
      hidden.forEach(([el]) => { el.style.opacity = ''; });
      parallaxTargets.forEach((el) => { el.style.translate = ''; });
      window.removeEventListener('scroll', onScroll);
      document.removeEventListener('pointermove', onPointerMove);
      document.documentElement.classList.remove('is-scrolled');
    };
  }, [pathname]);

  return null;
}
