import PrivacyPolicyPage from '../../src/airline/legalPages/PrivacyPolicy';
import PageSkin from '../../src/PageSkin.jsx';

export const metadata = {
  title: 'Privacy Policy | Sanatan Airlines',
  description: 'How Sanatan Airlines collects, uses and protects your personal data. Compliant with the IT Act 2000 and DGCA regulations.',
};

export default function Page() {
  return <PageSkin route="/privacy-policy"><PrivacyPolicyPage /></PageSkin>;
}
