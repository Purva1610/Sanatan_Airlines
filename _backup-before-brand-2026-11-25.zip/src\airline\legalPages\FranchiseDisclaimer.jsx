'use client';
import { LegalPage } from '../LegalPageLayout.jsx';

export default function FranchiseDisclaimerPage() {
  return (
    <LegalPage title="Franchise Disclaimer" lastUpdated="20 November 2026">
      <div className="legal-content">
        <p>This Franchise Disclaimer is published by Sanatan Airlines Private Limited ("Sanatan Airlines") in the interest of transparency to passengers, travel agents, business associates and the general public. Please read this notice carefully before engaging in any business arrangement purportedly connected with Sanatan Airlines.</p>

        <h2>1. Authorised Operations Only</h2>
        <p>Sanatan Airlines operates solely through its own directly authorised channels, including its official website (sanatanairlines.com), official mobile application, its own sales offices, and IATA-accredited travel agents with valid Appointment Agreements signed by Sanatan Airlines' authorised signatory. Any entity representing itself as a "franchise", "sub-brand", "regional franchise", "authorised distributor" or "exclusive representative" of Sanatan Airlines without possessing a valid, current Franchise Agreement executed by Sanatan Airlines' Board of Directors is acting without authority.</p>

        <h2>2. No Franchise Agreements Currently Issued</h2>
        <p>As of the Last Updated date of this disclaimer, Sanatan Airlines has not issued any franchise agreements to any third party in India or abroad. There are no authorised franchise operators, master franchisees, regional sub-franchisees or white-label partners of Sanatan Airlines currently operating. Any person or entity soliciting business, collecting money, or selling tickets under a claimed Sanatan Airlines franchise arrangement is doing so fraudulently.</p>

        <h2>3. Franchise Solicitations — Public Warning</h2>
        <p>Sanatan Airlines has become aware of fraudulent solicitations in which individuals or entities offer "Sanatan Airlines franchise opportunities" and collect deposits or registration fees from members of the public. <strong>Sanatan Airlines has not authorised any such solicitation.</strong> We urge the public not to pay any money in response to such offers. These are fraudulent acts that Sanatan Airlines has reported and will continue to report to law enforcement and regulatory authorities.</p>

        <h2>4. How to Verify Authorised Agents</h2>
        <ul>
          <li>All authorised travel agents selling Sanatan Airlines tickets are IATA-accredited and appear on the IATA Agency List.</li>
          <li>You may verify any agent's authorisation by calling our official number: <strong>1800 123 4567</strong> or emailing <strong>trade@sanatanairlines.com</strong>.</li>
          <li>Authorised agents will never ask for cash payments outside of an official booking system that issues a Sanatan Airlines PNR (Passenger Name Record).</li>
        </ul>

        <h2>5. Future Franchise Programmes</h2>
        <p>Sanatan Airlines may in the future establish authorised franchise, general sales agent (GSA) or distribution partner programmes. Any such programme will be announced exclusively through our official website and official press releases. Prior to any such announcement, no entity is authorised to represent itself as a Sanatan Airlines franchise or distribution partner.</p>

        <h2>6. Intellectual Property Notice</h2>
        <p>The Sanatan Airlines name, logo, "SkyNova" brand, "Seva | Satya | Vishwas" tagline and all associated marks are the registered or unregistered trademarks of Sanatan Airlines Private Limited. Unauthorised use of these marks in connection with fraudulent franchise operations or any other purpose is prohibited under the Trade Marks Act, 1999 and will be prosecuted.</p>

        <h2>7. Reporting Fraud</h2>
        <p>If you encounter a fraudulent franchise solicitation or any misuse of the Sanatan Airlines brand, please report it immediately to:</p>
        <ul>
          <li>Email: <strong>fraud@sanatanairlines.com</strong></li>
          <li>Phone: 1800 123 4567 (Toll-free, India)</li>
          <li>Your local police cybercrime cell or the National Cyber Crime Reporting Portal at cybercrime.gov.in</li>
        </ul>

        <h2>8. Disclaimer of Liability</h2>
        <p>Sanatan Airlines is not responsible for any loss, financial or otherwise, suffered by any person or entity as a result of dealings with unauthorised entities claiming to represent Sanatan Airlines as a franchise or in any similar capacity. We strongly urge all parties to verify the authenticity of any arrangement before making any financial commitment.</p>

        <h2>9. Contact</h2>
        <p>Sanatan Airlines Private Limited, Legal Department, Office No. 309, Elixa Park, Kolhapur – 416001. Email: <strong>legal@sanatanairlines.com</strong>.</p>
      </div>
    </LegalPage>
  );
}
