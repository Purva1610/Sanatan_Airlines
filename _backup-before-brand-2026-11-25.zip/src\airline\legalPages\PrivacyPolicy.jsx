'use client';
import { LegalPage } from '../LegalPageLayout.jsx';

export default function PrivacyPolicyPage() {
  return (
    <LegalPage title="Privacy Policy" lastUpdated="20 November 2026">
      <div className="legal-content">
        <p>This Privacy Policy describes how Sanatan Airlines Private Limited ("Sanatan Airlines", "we", "us" or "our") collects, uses, discloses and protects personal information when you access our website, mobile application, or use our airline services. We are committed to protecting your privacy in accordance with the Information Technology Act, 2000, the Information Technology (Reasonable Security Practices and Procedures and Sensitive Personal Data or Information) Rules, 2011, and applicable DGCA regulations.</p>

        <h2>1. Who We Are</h2>
        <p>Sanatan Airlines Private Limited is a scheduled airline operator incorporated under the Companies Act, 2013, with its registered office at Office No. 309, Elixa Park, Old Pune–Bangalore Highway, Shahupuri, Kolhapur, Maharashtra – 416001, India. CIN: [pending publication]. For privacy-related enquiries, write to: <strong>legal@sanatanairlines.com</strong>.</p>

        <h2>2. Information We Collect</h2>
        <h3>2.1 Information You Provide</h3>
        <ul>
          <li><strong>Booking information:</strong> Name, date of birth, passport/ID number, nationality, contact details, payment information and travel preferences.</li>
          <li><strong>Account information:</strong> SkyNova Rewards membership number, login credentials and profile details.</li>
          <li><strong>Enquiry information:</strong> Name, phone number, email address and service requirements submitted via our contact forms.</li>
          <li><strong>Special category data:</strong> Dietary preferences (for meal orders), medical requirements (for special assistance), and disability-related information — only as necessary to provide the requested service.</li>
        </ul>
        <h3>2.2 Information Collected Automatically</h3>
        <ul>
          <li>IP address, browser type and version, device identifiers, referring URLs and pages visited.</li>
          <li>Cookies and similar tracking technologies (see our Cookie Policy).</li>
          <li>Flight usage data including check-in time, seat selection and baggage data.</li>
        </ul>

        <h2>3. How We Use Your Information</h2>
        <ul>
          <li>To process bookings, issue tickets and manage your travel itinerary.</li>
          <li>To operate the SkyNova Rewards programme and credit miles earned.</li>
          <li>To send booking confirmations, boarding passes, flight status alerts and check-in reminders.</li>
          <li>To comply with DGCA, immigration, customs and security regulatory requirements.</li>
          <li>To improve our website, services and customer experience through analytics.</li>
          <li>To send promotional offers and marketing communications — only with your consent, which you may withdraw at any time.</li>
          <li>To respond to customer service enquiries and handle complaints.</li>
          <li>To prevent fraud, money laundering and other illegal activities.</li>
        </ul>

        <h2>4. Legal Basis for Processing</h2>
        <p>We process your personal data under the following legal bases:</p>
        <ul>
          <li><strong>Contract performance:</strong> Processing necessary to fulfil your booking and ticket contract.</li>
          <li><strong>Legal obligation:</strong> Compliance with DGCA regulations, anti-terrorism directives, and tax requirements.</li>
          <li><strong>Legitimate interests:</strong> Security, fraud prevention, service improvement and direct marketing to existing customers.</li>
          <li><strong>Consent:</strong> Email newsletters, non-essential cookies and sensitive data processing.</li>
        </ul>

        <h2>5. Sharing Your Information</h2>
        <p>We share your personal information only as follows:</p>
        <ul>
          <li><strong>Partner airlines and codeshare operators:</strong> To fulfil connecting flights and interline bookings.</li>
          <li><strong>Airport operators and ground handlers:</strong> As necessary for passenger processing, security and boarding.</li>
          <li><strong>Government authorities:</strong> DGCA, immigration, customs, Advance Passenger Information (API) and other regulatory bodies as required by law.</li>
          <li><strong>Payment processors:</strong> Encrypted payment data is shared with PCI-DSS certified payment gateway partners only.</li>
          <li><strong>Service providers:</strong> IT, analytics, catering, hotel and car rental partners under strict data processing agreements.</li>
          <li><strong>SkyNova loyalty partners:</strong> Miles earning and redemption data shared with named partners under programme terms.</li>
        </ul>
        <p>We do not sell your personal data to third parties.</p>

        <h2>6. International Data Transfers</h2>
        <p>When you travel on international routes, your passenger data is transferred to destination country authorities as required by law (including Advance Passenger Information). We ensure appropriate safeguards are in place for all international transfers, including standard contractual clauses where applicable.</p>

        <h2>7. Data Retention</h2>
        <ul>
          <li>Booking records: 7 years (tax and regulatory compliance)</li>
          <li>Passenger Name Records (PNR): 5 years</li>
          <li>SkyNova account data: Duration of membership plus 2 years</li>
          <li>Enquiry form data: 2 years</li>
          <li>Cookie data: As specified in our Cookie Policy</li>
        </ul>

        <h2>8. Your Rights</h2>
        <p>Under applicable Indian law, you have the right to:</p>
        <ul>
          <li>Access the personal data we hold about you</li>
          <li>Correct inaccurate or incomplete data</li>
          <li>Request deletion of data no longer necessary (subject to legal obligations)</li>
          <li>Withdraw consent for marketing communications at any time</li>
          <li>Lodge a complaint with the relevant data protection authority</li>
        </ul>
        <p>To exercise any of these rights, write to <strong>legal@sanatanairlines.com</strong> with proof of identity.</p>

        <h2>9. Security</h2>
        <p>We implement industry-standard security measures including TLS encryption, PCI-DSS compliant payment handling, role-based access controls and regular security audits. Despite these measures, no transmission over the internet is completely secure, and we cannot guarantee absolute security.</p>

        <h2>10. Cookies</h2>
        <p>We use cookies and similar technologies. For full details, please read our <a href="/cookie-policy">Cookie Policy</a>.</p>

        <h2>11. Children's Privacy</h2>
        <p>We do not knowingly collect personal data from children under 13 without verifiable parental consent. Parents wishing to review or delete a child's data should contact <strong>legal@sanatanairlines.com</strong>.</p>

        <h2>12. Changes to This Policy</h2>
        <p>We may update this Privacy Policy from time to time. The revised version will be published on our website with a new Last Updated date. Continued use of our services after any change constitutes acceptance of the updated policy.</p>

        <h2>13. Contact Us</h2>
        <p>Data Protection Officer / Privacy Officer<br />Sanatan Airlines Private Limited<br />Office No. 309, Elixa Park, Kolhapur – 416001<br />Email: <strong>legal@sanatanairlines.com</strong><br />Phone: 1800 123 4567 (Toll-free, India)</p>
      </div>
    </LegalPage>
  );
}
