'use client';

import { ArrowUpRight, ShieldCheck } from 'lucide-react';
import { usePathname } from 'next/navigation';
import { LeadFeedback, LeadHoneypot, useLeadCapture } from './useLeadCapture.js';
import SiteFooter from './SiteFooter.jsx';
import { FaqStructuredData } from './SeoStructuredData.jsx';
import WhyChooseSanatan from './WhyChooseSanatan.jsx';

const officeAddress = 'Office No. 309, Elixa Park, Old Pune–Bangalore Highway, Shahupuri, Kolhapur, Maharashtra – 416001';

const content = {
  '/about': {
    eyebrow: 'ABOUT SANATAN',
    title: 'Three connected service areas. One clear approach.',
    description: 'Sanatan Airlines Private Limited brings together aviation facilitation, international travel membership and global business-service enquiries. Each service starts with a clear brief and transparent next steps.',
    sections: [
      ['Aviation', 'Private jet charter facilitation, helicopter coordination, air ambulance coordination, aircraft advisory, leasing and aviation concierge enquiries. Flights are subject to licensed operator confirmation.'],
      ['International Club', 'A developing membership concept for international travel planning. Eligibility, price, entitlements and benefits remain subject to approved terms.'],
      ['Global Network', 'Information and enquiries across tourism, education, employment assistance, business, property, investment introductions, PR and trade. Regulated service delivery belongs to authorized providers.'],
    ],
  },
  '/leadership': {
    eyebrow: 'LEADERSHIP',
    title: 'Leadership profiles will be published after approval.',
    description: 'Names, roles, biographies and photographs are not shown until reviewed and approved by management and the individuals concerned.',
    sections: [['Leadership information', 'No leadership names, credentials or photographs are published on this page at this time.']],
  },
  '/contact': {
    eyebrow: 'CONTACT',
    title: 'Contact Sanatan Airlines',
    description: 'Send a general enquiry or find the Kolhapur office address.',
    sections: [],
  },
  '/partners': {
    eyebrow: 'PARTNERS & CREDENTIALS',
    title: 'Trust requires permission and verification.',
    description: 'Partner names, operator details, credentials and logos are shared only when verified, relevant and approved for publication.',
    sections: [['Partner disclosure', 'No partner logos or endorsements are displayed. For regulated or operator-delivered services, request the provider identity and applicable authorization before engagement.']],
    action: ['Partner enquiry', '/partners/enquiry'],
  },
  '/compliance': {
    eyebrow: 'GOVERNANCE & COMPLIANCE',
    title: 'Clear boundaries are part of good service.',
    description: 'The site is an information and enquiry platform. It is not a booking engine, emergency dispatch service, recruitment guarantee or regulated investment-advice service.',
    sections: [
      ['Aviation', 'Sanatan Airlines does not represent that it operates scheduled airline services, owns aircraft or holds an NSOP permit. Flights require confirmation by an appropriately licensed operating partner.'],
      ['Regulated services', 'Employment, immigration, education, property and investment outcomes are not guaranteed. Regulated delivery must be performed by appropriately authorized entities.'],
      ['Content approval', 'Pricing, service availability, partner credentials and legal terms are published only after approval by the responsible business owner and relevant reviewers.'],
    ],
    action: ['View aviation disclaimer', '/aviation/disclaimer'],
  },
  '/insights': {
    eyebrow: 'INSIGHTS',
    title: 'Editorial content is being prepared.',
    description: 'Aviation explainers, travel guides and company updates will appear here after editorial and compliance review.',
    sections: [['No articles published', 'There are no approved articles available yet. We will not publish duplicate or placeholder destination pages.']],
  },
  '/faqs': {
    eyebrow: 'FREQUENTLY ASKED QUESTIONS',
    title: 'A few useful answers before you enquire.',
    description: 'General information about how Sanatan services and enquiries work.',
    faqs: [
      ['Does an enquiry confirm a booking?', 'No. An enquiry is not a booking, price confirmation or guarantee of availability. Relevant operators and terms are confirmed individually.'],
      ['Does Sanatan operate scheduled flights or own aircraft?', 'This website does not represent that Sanatan operates scheduled airline services, owns aircraft or holds an NSOP permit. Flight services require a licensed operating partner.'],
      ['Are membership prices and benefits finalized?', 'No. International Club pricing, benefits, eligibility and entitlements remain subject to approved terms.'],
      ['Can this website handle an emergency?', 'No. The air ambulance form is not emergency dispatch. For urgent help, contact local emergency services.'],
      ['Are jobs, admissions, visas or investment returns guaranteed?', 'No. Employment, admission, immigration, investment and property outcomes are not guaranteed.'],
    ],
  },
  '/terms': { eyebrow: 'TERMS OF USE', title: 'Terms of Use are pending legal review.', description: 'The final Terms of Use will be published after approval by Sanatan Legal.', sections: [['Pre-launch status', 'Do not rely on this website as a contract, booking, offer or confirmation of a service.']] },
  '/cookie-policy': { eyebrow: 'COOKIE POLICY', title: 'Cookie information is pending legal review.', description: 'The final cookie and analytics notice will be published after the applicable tracking and consent configuration is approved.', sections: [['Current analytics', 'Analytics is disabled unless a measurement ID, approved privacy configuration and explicit user consent are all present.']] },
  '/cancellation-refund': { eyebrow: 'CANCELLATION & REFUND', title: 'Cancellation and refund terms are pending approval.', description: 'Service-specific cancellation and refund terms must be approved and provided before a customer makes a commitment.', sections: [['Pre-launch status', 'No cancellation or refund entitlement is implied by this website.']] },
  '/aviation/disclaimer': { eyebrow: 'AVIATION DISCLAIMER', title: 'Flight services require operator confirmation.', description: 'This website does not display live aircraft availability, instant pricing or confirmed booking capability.', sections: [['Operating partner', 'Where relevant, the licensed operating partner and applicable licensing details must be identified before a flight is confirmed. Sanatan Airlines does not represent that it owns aircraft or holds an NSOP permit.'], ['Emergency requests', 'The air ambulance enquiry form is not emergency dispatch. For urgent help, call local emergency services.']] },
  '/accessibility': { eyebrow: 'ACCESSIBILITY', title: 'Accessibility information and feedback.', description: 'The site is being developed with keyboard access, visible focus, semantic controls and reduced-motion support. A formal WCAG 2.2 AA audit has not yet been completed.', sections: [['Request assistance', 'For accessibility help or to report a barrier, use the general contact form. Please do not include sensitive personal information.']], action: ['Contact the team', '/contact'] },
  '/grievance': { eyebrow: 'GRIEVANCE & COMPLAINTS', title: 'Grievance contact details are pending approval.', description: 'A designated grievance contact and escalation process will be published after Operations and Legal approval.', sections: [['Non-urgent enquiries', 'For a non-urgent service question, use the contact form. This website is not an emergency support channel.']], action: ['Submit a general enquiry', '/contact'] },
};

function CorporateHeader() {
  return (
    <>
      <div className="utility-bar"><div className="utility-inner"><span>Sanatan Airlines Private Limited</span><a href="/contact">Contact the team <ArrowUpRight size={13} aria-hidden="true" /></a></div></div>
      <header className="site-header corporate-header">
        <a className="brand" href="/" aria-label="Sanatan Airlines home"><span className="brand-mark" aria-hidden="true"><span>S</span></span><span className="brand-name">SANATAN<span>AIRLINES</span></span></a>
        <nav className="desktop-nav corporate-nav" aria-label="Main navigation"><a href="/">Home</a><a href="/aviation">Aviation</a><a href="/club">International Club</a><a href="/global-services">Global Services</a><a href="/franchise">Franchise</a></nav>
        <a className="header-cta" href="/enquire">Talk to our team <ArrowUpRight size={15} /></a>
      </header>
    </>
  );
}

function ContactForm() {
  const lead = useLeadCapture('general_enquiry');
  return (
    <form className="corporate-contact-form" {...lead.formProps}>
      <LeadHoneypot />
      <span className="eyebrow">GENERAL ENQUIRY</span>
      <label><span>Name *</span><input name="name" autoComplete="name" required /></label>
      <label><span>Mobile number *</span><input name="phone" type="tel" autoComplete="tel" defaultValue="+91 " pattern="\+?[0-9][0-9\s.\x2d]{6,19}" title="Enter an international phone number, including country code" required /></label>
      <label><span>Email *</span><input name="email" type="email" autoComplete="email" required /></label>
      <label><span>City / country</span><input name="location" autoComplete="country-name" /></label>
      <label><span>Service category *</span><select name="serviceCategory" defaultValue="" required><option value="" disabled>Select a service</option><option>Aviation</option><option>International Club</option><option>Global Services</option><option>Franchise</option><option>Partner enquiry</option><option>Other</option></select></label>
      <label><span>Message *</span><textarea name="message" rows="4" required /></label>
      <label className="corporate-consent"><input name="consent" type="checkbox" required /><span>I agree to be contacted about this enquiry. <a href="/privacy-policy">Privacy Policy</a></span></label>
      <button className="button button-dark" type="submit" disabled={lead.isSubmitting}>{lead.isSubmitting ? 'Sending…' : 'Send enquiry'} <ArrowUpRight size={15} /></button>
      <LeadFeedback status={lead.status} />
    </form>
  );
}

function ContactPage() {
  return (
    <section className="corporate-content contact-page">
      <div><span className="eyebrow">CONTACT</span><h1>Tell us what<br /><em>you need.</em></h1><p>Share a service enquiry and the appropriate team can follow up. Phone and email contact details will be added after approval.</p><div className="corporate-address"><ShieldCheck size={18} /><div><strong>Kolhapur Office</strong><address>{officeAddress}</address></div></div></div>
      <ContactForm />
    </section>
  );
}

export default function CorporatePage() {
  const pathname = usePathname() || '/about';
  const page = content[pathname];
  if (!page) return <div className="corporate-page"><CorporateHeader /><main className="corporate-content"><span className="eyebrow">CONTENT</span><h1>Information pending approval.</h1></main><SiteFooter /></div>;

  return (
    <div className="corporate-page">
      <CorporateHeader />
      <main>
        {pathname === '/contact' ? <ContactPage /> : (
          <section className="corporate-content">
            <span className="eyebrow">{page.eyebrow}</span><h1>{page.title}</h1><p className="corporate-lede">{page.description}</p>
            {page.sections && <div className="corporate-sections">{page.sections.map(([title, copy]) => <article key={title}><h2>{title}</h2><p>{copy}</p></article>)}</div>}
            {page.faqs && <div className="corporate-faqs">{page.faqs.map(([question, answer]) => <details key={question}><summary>{question}<span>+</span></summary><p>{answer}</p></details>)}</div>}
            {page.faqs && <FaqStructuredData items={page.faqs} />}
            {page.action && <a className="button button-dark" href={page.action[1]}>{page.action[0]} <ArrowUpRight size={15} /></a>}
          </section>
        )}
      </main>
      {pathname === '/about' && <WhyChooseSanatan />}
      <SiteFooter />
    </div>
  );
}
