'use client';
import { Accessibility, CheckCircle, ClipboardList, Info, Mail, MapPin, MessageCircle, Phone, PlaneTakeoff, Smartphone, Trophy } from 'lucide-react';
import Link from 'next/link';
import { PageLayout } from '../AirlineLayout.jsx';
import { useI18n } from '../i18n/I18nContext.jsx';

const OFFICES = [
  { city: 'Mumbai (HQ)', address: 'Sanatan House, Terminal 2 Complex, CSI Airport, Mumbai — 400099', phone: '+91 22 6789 0100', hours: 'Mon–Sat 09:00–21:00' },
  { city: 'Delhi', address: 'Level 3, Aerocity Metro Tower, IGI Airport, New Delhi — 110037', phone: '+91 11 4567 8900', hours: 'Mon–Sat 09:00–21:00' },
  { city: 'Bengaluru', address: 'Kempegowda International Airport, Terminal 1, Devanahalli — 562300', phone: '+91 80 6789 0200', hours: 'Mon–Fri 09:00–18:00' },
  { city: 'Dubai', address: 'Al Maktoum International Airport, Emirates Road, Dubai — UAE', phone: '+971 4 234 5678', hours: 'Mon–Sat 08:00–22:00' },
  { city: 'London', address: 'Heathrow Airport, Terminal 4, Zone B, London — TW6 3AH', phone: '+44 20 8765 4321', hours: 'Mon–Fri 08:00–20:00' },
  { city: 'Singapore', address: 'Changi Airport, Terminal 3, Level B2, Singapore — 819666', phone: '+65 6789 0123', hours: 'Daily 07:00–22:00' },
];

export default function ContactPage() {
  const { t } = useI18n();
  return (
    <PageLayout>
      {/* ── FLAME HERO — distinct from every navy hero ── */}
      <section style={{ background: 'linear-gradient(135deg, #c43200 0%, #ff4800 50%, #ff6b00 100%)', padding: 'clamp(56px,8vw,100px) 24px', position: 'relative', overflow: 'hidden' }}>
        {/* Decorative circle */}
        <div style={{ position: 'absolute', right: -120, top: -120, width: 480, height: 480, borderRadius: '50%', background: 'rgba(255,255,255,0.07)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', right: 60, bottom: -80, width: 280, height: 280, borderRadius: '50%', background: 'rgba(255,255,255,0.05)', pointerEvents: 'none' }} />
        <div style={{ maxWidth: 'var(--al-container)', margin: '0 auto', position: 'relative', zIndex: 1 }}>
          <div style={{ maxWidth: 600 }}>
            <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: '0.16em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.75)', marginBottom: 12 }}>We Are Here to Help</div>
            <h1 style={{ fontFamily: "'Playfair Display',Georgia,serif", fontSize: 'clamp(32px,5vw,56px)', fontWeight: 700, color: '#fff', lineHeight: 1.1, marginBottom: 16 }}>Contact<br />Sanatan Airlines</h1>
            <p style={{ fontSize: 16, color: 'rgba(255,255,255,0.85)', lineHeight: 1.65 }}>Reach our team by phone, email, chat or at any of our airport offices. We are available 24×7 for urgent travel assistance.</p>
            {/* Quick channels inline */}
            <div style={{ display: 'flex', gap: 24, marginTop: 32, flexWrap: 'wrap' }}>
              {[['📞','1800 123 4567','Toll-free 24/7'],['+91','98765 00000','WhatsApp'],['✉','support@','Replies in 24h']].map(([ic,val,note]) => (
                <div key={val} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(255,255,255,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, flexShrink: 0 }}>{ic}</div>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 700, color: '#fff' }}>{val}</div>
                    <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.65)' }}>{note}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Quick contact channels */}
      <section className="al-section al-section--sky">
        <div className="al-container">
          <div className="al-cards al-cards--4">
            {[
              { icon: <Phone size={20}/>, channel: '24/7 Helpline', detail: '+91 1800 123 4567 (India, toll-free)', note: 'Available round the clock for urgent flight assistance' },
              { icon: <MessageCircle size={20}/>, channel: 'Live Chat', detail: 'Available on website and mobile app', note: 'Average wait time under 3 minutes' },
              { icon: <Mail size={20}/>, channel: 'Email Support', detail: 'support@sanatanairlines.com', note: 'Responses within 24 hours for general queries' },
              { icon: <Smartphone size={20}/>, channel: 'WhatsApp', detail: '+91 98765 00000', note: 'Text or voice — available 06:00–23:00 IST' },
            ].map((c) => (
              <div key={c.channel} className="al-card" style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 36, marginBottom: 12 }}>{c.icon}</div>
                <h3>{c.channel}</h3>
                <div style={{ fontWeight: 700, color: 'var(--al-navy)', marginBottom: 8, fontSize: 14 }}>{c.detail}</div>
                <p>{c.note}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Complaint form */}
      <section className="al-section">
        <div className="al-container">
          <div className="al-two-col">
            <div>
              <div className="al-section-eyebrow">Get in Touch</div>
              <h2 style={{ fontFamily: "'Playfair Display',Georgia,serif", fontSize: 'clamp(24px,3vw,36px)', marginBottom: 20 }}>Send Us a Message</h2>
              <p style={{ fontSize: 15, color: 'var(--al-muted)', lineHeight: 1.75, marginBottom: 20 }}>Use this form for general enquiries, feedback or complaints. For urgent assistance related to a flight today, please call our 24/7 helpline.</p>
              <ul className="al-list">
                <li>Booking queries and changes</li>
                <li>Refund and compensation claims</li>
                <li>Lost and damaged baggage</li>
                <li>Accessibility and special assistance</li>
                <li>Feedback and compliments</li>
                <li>Media and PR enquiries</li>
              </ul>
            </div>
            <div className="al-form-wrap" style={{ padding: 32 }}>
              <form className="al-form" style={{ gridTemplateColumns: '1fr 1fr' }} onSubmit={e => e.preventDefault()}>
                <div className="al-form-group"><label>Full Name</label><input required placeholder="Your name" /></div>
                <div className="al-form-group"><label>Email</label><input type="email" required placeholder="you@example.com" /></div>
                <div className="al-form-group"><label>Phone</label><input type="tel" placeholder="+91 98765 43210" /></div>
                <div className="al-form-group"><label>Booking Reference (if applicable)</label><input placeholder="e.g. SN2024ABC" /></div>
                <div className="al-form-group" style={{ gridColumn: '1 / -1' }}><label>Category</label>
                  <select>
                    <option>General Enquiry</option>
                    <option>Booking / Ticketing</option>
                    <option>Baggage Complaint</option>
                    <option>Flight Delay / Cancellation</option>
                    <option>Refund Request</option>
                    <option>Accessibility Assistance</option>
                    <option>Compliment / Feedback</option>
                    <option>Media / PR</option>
                  </select>
                </div>
                <div className="al-form-group" style={{ gridColumn: '1 / -1' }}><label>Message</label><textarea required placeholder="Describe your enquiry..." style={{ minHeight: 120 }} /></div>
                <div className="al-form-actions" style={{ gridColumn: '1 / -1' }}><button className="al-btn-primary" type="submit">Send Message →</button></div>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Airport offices */}
      <section className="al-section al-section--light">
        <div className="al-container">
          <div className="al-section-header"><div className="al-section-eyebrow">At the Airport</div><h2>Our Office Locations</h2></div>
          <div className="al-cards al-cards--3">
            {OFFICES.map((o) => (
              <div key={o.city} className="al-card">
                <div style={{ marginBottom: 10, color: 'var(--al-navy)' }}><MapPin size={22}/></div>
                <h3>{o.city}</h3>
                <p style={{ marginBottom: 8 }}>{o.address}</p>
                <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--al-navy)', marginBottom: 4 }}>{o.phone}</div>
                <div style={{ fontSize: 13, color: 'var(--al-flame)' }}>{o.hours}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Images */}
      <section className="al-section">
        <div className="al-container">
          <div className="al-gallery">
            <div className="al-gallery-img"><img src="https://images.unsplash.com/photo-1529108190281-9a4f620bc2d8?w=600&q=80" alt="Airport service desk" /></div>
            <div className="al-gallery-img"><img src="https://images.unsplash.com/photo-1521791055366-0d553872952f?w=600&q=80" alt="Customer service" /></div>
            <div className="al-gallery-img"><img src="https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=600&q=80" alt="Mobile support" /></div>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="al-section al-section--light">
        <div className="al-container">
          <div className="al-section-header"><h2>Contact FAQs</h2></div>
          <div className="al-faqs">
            {[
              ['What is the fastest way to get help for a flight today?', 'Call our 24/7 helpline at +91 1800 123 4567. This is the priority line for same-day travel assistance. Live chat on the website is also very fast.'],
              ['How long does it take to get a refund?', 'Refunds to credit/debit cards take 7–14 business days. UPI refunds are processed within 3 business days. Travel vouchers are issued within 2 business days.'],
              ['Can I complain about crew behaviour?', 'Yes. All feedback on our crew — positive or negative — is taken seriously. Submit a detailed description through the contact form or email crew.relations@sanatanairlines.com.'],
              ['How do I escalate a complaint?', 'If you are not satisfied with the initial response, write to our Nodal Officer at nodal@sanatanairlines.com or the Appellate Authority at appellate@sanatanairlines.com, as required by DGCA grievance regulations.'],
              ['Is there a corporate or bulk booking helpline?', 'Yes — corporate accounts have a dedicated account manager. For initial enquiries, write to corporate@sanatanairlines.com or use the Corporate Travel page.'],
            ].map(([q, a]) => (
              <details key={q} className="al-faq"><summary>{q}</summary><p>{a}</p></details>
            ))}
          </div>
        </div>
      </section>

      <section className="al-section" style={{ paddingTop: 0 }}>
        <div className="al-container">
          <div className="al-related">
            {[[<ClipboardList size={20}/>, 'Manage Booking', '/airline/manage-booking'], [<CheckCircle size={20}/>, 'Check-in Online', '/airline/check-in'], [<PlaneTakeoff size={20}/>, 'Flight Status', '/airline/flight-status'], [<Accessibility size={20}/>, 'Special Assistance', '/airline/special-assistance'], [<Info size={20}/>, 'About Us', '/airline/about'], [<Trophy size={20}/>, 'SkyNova Rewards', '/airline/skynova-rewards']].map(([icon, label, href]) => (
              <Link key={href} href={href} className="al-related-link"><span>{icon}</span>{label}</Link>
            ))}
          </div>
          <div className="al-disclaimer" style={{ marginTop: 32 }}><strong>Consumer Rights:</strong> Passengers have rights under DGCA CAR Section 3, Series M, Part IV. For flight delay, cancellation or denied boarding, you may be entitled to compensation as per applicable regulations. Contact our Consumer Affairs team for details.</div>
        </div>
      </section>
    </PageLayout>
  );
}
