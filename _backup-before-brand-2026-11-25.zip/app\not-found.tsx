import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';

export default function NotFound() {
  return (
    <main className="not-found-page">
      <span className="eyebrow">404 / PAGE NOT FOUND</span>
      <h1>This page is not available.</h1>
      <p>The address may have changed, or the page may not exist.</p>
      <Link className="button button-dark" href="/">
        <ArrowLeft size={15} /> Return to Sanatan Airlines
      </Link>
    </main>
  );
}
