'use client';
import { LegalPage } from '../LegalPageLayout.jsx';

export default function AviationDisclaimerPage() {
  return (
    <LegalPage title="Aviation Disclaimer" lastUpdated="20 November 2026">
      <div className="legal-content">
        <p>This Aviation Disclaimer sets out important notices and limitations applicable to all flights operated by or on behalf of Sanatan Airlines Private Limited ("Sanatan Airlines"). Aviation is a heavily regulated industry and all operations are conducted under licences and approvals issued by the Directorate General of Civil Aviation (DGCA), Government of India, and applicable international aviation authorities. By purchasing a ticket or travelling on any Sanatan Airlines flight, you acknowledge and accept the following.</p>

        <h2>1. Regulatory Compliance</h2>
        <p>All Sanatan Airlines flight operations are conducted in full compliance with:</p>
        <ul>
          <li>The Aircraft Act, 1934 and Aircraft Rules, 1937</li>
          <li>DGCA Civil Aviation Requirements (CARs) and Civil Aviation Orders (CAOs)</li>
          <li>International Civil Aviation Organization (ICAO) Standards and Recommended Practices (SARPs)</li>
          <li>Applicable bilateral Air Services Agreements for international routes</li>
          <li>IATA Dangerous Goods Regulations for cargo carriage</li>
        </ul>

        <h2>2. Schedule and Route Changes</h2>
        <p>All published flight schedules are indicative and subject to change without prior notice for reasons including, but not limited to, air traffic control restrictions, weather conditions, aircraft serviceability, regulatory requirements, slot allocation and force majeure. Sanatan Airlines' obligation in the event of significant schedule changes is limited to rebooking or refund as described in our <a href="/cancellation-refund-policy">Cancellation & Refund Policy</a>.</p>

        <h2>3. Safety Instructions</h2>
        <ul>
          <li>Passengers must comply with all safety instructions given by the Captain and cabin crew at all times during the flight.</li>
          <li>The Captain of the aircraft has final authority over the safety and operation of the flight. The Captain's decisions regarding diversions, delays, passenger removal or any other safety-related matter are final and binding.</li>
          <li>All electronic devices must be switched to flight mode as instructed by the crew. Personal electronic devices that cannot be switched to flight mode must be switched off completely.</li>
          <li>The carriage of lithium batteries is subject to DGCA and IATA regulations. Spare lithium batteries must be carried in cabin baggage only.</li>
        </ul>

        <h2>4. Dangerous Goods</h2>
        <p>Certain articles are prohibited or restricted in passenger baggage by DGCA regulations and IATA Dangerous Goods Regulations. Passengers who knowingly carry prohibited dangerous goods may be subject to prosecution. For a full list, see our <a href="/airline/dangerous-goods">Dangerous Goods page</a>. Sanatan Airlines is not liable for damage caused by undeclared dangerous goods.</p>

        <h2>5. Health and Fitness to Fly</h2>
        <ul>
          <li>Passengers with medical conditions are advised to consult their physician before travelling. Sanatan Airlines reserves the right to require a medical clearance certificate (MEDIF) from passengers whose medical condition may affect safety or the comfort of other passengers.</li>
          <li>Pregnant passengers beyond 32 weeks of gestation are required to produce a medical certificate confirming fitness to fly. Travel is not permitted beyond 36 weeks.</li>
          <li>Sanatan Airlines is not responsible for any in-flight medical events arising from pre-existing conditions of which we were not informed.</li>
        </ul>

        <h2>6. Limitation of Liability for Delay</h2>
        <p>Sanatan Airlines' liability for passenger delay is governed by the Carriage by Air Act, 1972 and the Montreal Convention (where applicable). For domestic flights, compensation for delay of 2 hours or more is provided per DGCA Passenger Charter guidelines. For international flights, liability limits are set by the Montreal Convention. Sanatan Airlines is not liable for indirect or consequential loss arising from delays.</p>

        <h2>7. No Guarantee of Continuity of Operations</h2>
        <p>Sanatan Airlines' ability to operate flights depends on continued regulatory authorisation by DGCA and other competent authorities. All routes are operated under DGCA route approvals which may be varied, suspended or revoked by the regulator. Sanatan Airlines does not guarantee the continuity of any route and is not liable for route discontinuation imposed by regulatory action.</p>

        <h2>8. Cargo and Mail</h2>
        <p>All cargo and mail carried on Sanatan Airlines flights is accepted only under Sanatan Airlines' Conditions of Carriage for Cargo, Air Waybill terms, and applicable IATA and DGCA regulations. The shipper is responsible for ensuring cargo is accurately declared and lawfully packaged.</p>

        <h2>9. Website Information Accuracy</h2>
        <p>Information published on this website regarding fares, schedules, policies, aircraft types and partner services is provided in good faith and is subject to change without notice. Sanatan Airlines does not warrant the accuracy, completeness or timeliness of information on this website and is not liable for reliance on such information.</p>

        <h2>10. Contact</h2>
        <p>For safety concerns or regulatory compliance queries: <strong>safety@sanatanairlines.com</strong>. For general enquiries: 1800 123 4567 (Toll-free, India).</p>
      </div>
    </LegalPage>
  );
}
