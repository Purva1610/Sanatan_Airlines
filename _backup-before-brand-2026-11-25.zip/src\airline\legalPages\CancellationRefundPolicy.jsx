'use client';
import { LegalPage } from '../LegalPageLayout.jsx';

export default function CancellationRefundPolicyPage() {
  return (
    <LegalPage title="Cancellation & Refund Policy" lastUpdated="20 November 2026">
      <div className="legal-content">
        <p>This Cancellation & Refund Policy explains the rules applicable to cancellations, changes and refunds for tickets issued by Sanatan Airlines Private Limited. All provisions are subject to the fare rules applicable to your ticket, which are displayed at the time of booking and form part of your contract of carriage. Sanatan Airlines complies with applicable DGCA Passenger Charter and consumer protection regulations.</p>

        <h2>1. Fare Families Overview</h2>
        <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: 24 }}>
          <thead>
            <tr style={{ background: '#f0f4ff' }}>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7' }}>Fare Type</th>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7' }}>Cancellation Fee</th>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7' }}>Date Change Fee</th>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7' }}>Refund to Original Source</th>
            </tr>
          </thead>
          <tbody>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Light (Saver)</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>₹3,500</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>₹2,500 + fare diff.</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>After deduction of fee</td></tr>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Classic</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>₹2,000</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>₹1,500 + fare diff.</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>After deduction of fee</td></tr>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Flex</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>₹500</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Free (1 change)</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Full refund (minus ₹500)</td></tr>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Business Flex</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Free</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Free (unlimited)</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Full refund</td></tr>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Group Fare</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>As per group contract</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>As per group contract</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Per group agreement</td></tr>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Award Ticket</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>1,500 miles redeposit fee</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>1,000 miles change fee</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Miles redeposited (taxes refunded)</td></tr>
          </tbody>
        </table>

        <h2>2. Cancellation Time Bands</h2>
        <ul>
          <li><strong>More than 96 hours before departure:</strong> Cancellation fees as per fare type apply. Refund processed within 7 working days.</li>
          <li><strong>24–96 hours before departure:</strong> Higher cancellation fee applies. Minimum refund of taxes and surcharges guaranteed.</li>
          <li><strong>Less than 24 hours before departure:</strong> No monetary refund except government taxes and airport charges which are always refundable.</li>
          <li><strong>No-show (after departure):</strong> No refund. Taxes and fees may be claimed within 60 days.</li>
        </ul>

        <h2>3. Airline-Initiated Cancellations</h2>
        <ul>
          <li>If Sanatan Airlines cancels a flight, passengers are entitled to: (a) rebooking on the next available flight at no additional charge; or (b) a full refund to the original payment source within 7 working days.</li>
          <li>In cases of cancellation due to extraordinary circumstances (force majeure, government directives), alternative travel credit may be offered per DGCA guidelines.</li>
          <li>Compensation for significant delays and cancellations is provided per DGCA Circular requirements.</li>
        </ul>

        <h2>4. Refund Process</h2>
        <ul>
          <li>Refund requests must be submitted via Manage Booking on our website or through the original booking channel.</li>
          <li>Refunds are credited to the original payment method: credit/debit card refunds within 7–10 working days; net banking within 5 working days; UPI within 24–48 hours; travel agent bookings through the agent's BSP account.</li>
          <li>Third-party booking platform refunds are subject to that platform's processing timelines.</li>
          <li>Service fees (booking convenience fee, seat selection fee) are non-refundable unless the cancellation is caused by Sanatan Airlines.</li>
        </ul>

        <h2>5. Special Circumstances</h2>
        <ul>
          <li><strong>Medical emergency:</strong> Full fee waiver may be granted on submission of a valid medical certificate within 7 days of the scheduled flight date.</li>
          <li><strong>Bereavement:</strong> Fee waiver for immediate family (spouse, parent, child, sibling) on submission of death certificate and relationship proof.</li>
          <li><strong>Visa refusal:</strong> Partial refund of base fare (less ₹1,000 processing fee) on submission of official visa refusal letter.</li>
        </ul>

        <h2>6. Contact</h2>
        <p>For refund queries: <strong>refunds@sanatanairlines.com</strong> | 1800 123 4567 (Toll-free, India). Include your booking reference number in all correspondence.</p>
      </div>
    </LegalPage>
  );
}
