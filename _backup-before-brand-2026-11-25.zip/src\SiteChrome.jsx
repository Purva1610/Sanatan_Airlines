'use client';

import { useEffect, useState } from 'react';
import { ArrowUpRight, Facebook, Instagram, Linkedin, Mail, MapPin, Menu, ShieldCheck, X, Youtube } from 'lucide-react';

const homeLinks = [
  ['Services', '#pillars'],
  ['International Club', '#pillars'],
  ['Global Network', '#global-network'],
  ['Why Sanatan', '#why-sanatan'],
  ['Insights', '#insights'],
  ['About', '#about'],
];

export function BrandMark({ href = '/' }) {
  return (
    <a className="sa-brand" href={href} aria-label="Sanatan Aviation home">
      <span className="sa-brand-mark" aria-hidden="true"><span className="sa-brand-glyph">S</span></span>
      <span className="sa-brand-text">SANATAN<small>AVIATION</small></span>
    </a>
  );
}

export function SiteHeader({ links = homeLinks, ctaHref = '#consultation', ctaLabel = 'Request a Consultation' }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (!open) return undefined;
    const onEscape = (event) => { if (event.key === 'Escape') setOpen(false); };
    document.addEventListener('keydown', onEscape);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onEscape);
      document.body.style.overflow = '';
    };
  }, [open]);

  return (
    <>
      <header className={`sa-header${scrolled ? ' is-scrolled' : ''}`}>
        <div className="sa-header-inner">
          <BrandMark />
          <nav className="sa-nav" aria-label="Main navigation">
            {links.map(([label, href]) => <a key={label} href={href}>{label}</a>)}
          </nav>
          <a className="sa-header-cta" href={ctaHref}>{ctaLabel} <ArrowUpRight size={14} /></a>
          <button
            className="sa-menu-toggle"
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
            onClick={() => setOpen((value) => !value)}
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </header>
      {open && (
        <div className="sa-drawer" role="dialog" aria-modal="true" aria-label="Navigation">
          <button className="sa-drawer-close" aria-label="Close menu" onClick={() => setOpen(false)}><X size={20} /></button>
          {links.map(([label, href]) => (
            <a key={label} href={href} onClick={() => setOpen(false)}>{label}<ArrowUpRight size={17} /></a>
          ))}
          <a className="sa-drawer-cta" href={ctaHref} onClick={() => setOpen(false)}>{ctaLabel} <ArrowUpRight size={16} /></a>
        </div>
      )}
    </>
  );
}

export function SiteFooter() {
  return (
    <footer className="sa-footer" id="contact">
      <div className="sa-container">
        <div className="sa-footer-grid sa-footer-grid-aviation">
          <div className="sa-footer-brand">
            <BrandMark />
            <p>
              Aviation coordination, international travel membership and global services — rooted
              in Sanatan values of trust, seva and dharma.
            </p>
            <div className="sa-footer-social" aria-label="Social channels">
              <button type="button" aria-label="Instagram — channel coming soon" title="Channel coming soon"><Instagram size={16} /></button>
              <button type="button" aria-label="Facebook — channel coming soon" title="Channel coming soon"><Facebook size={16} /></button>
              <button type="button" aria-label="LinkedIn — channel coming soon" title="Channel coming soon"><Linkedin size={16} /></button>
              <button type="button" aria-label="YouTube — channel coming soon" title="Channel coming soon"><Youtube size={16} /></button>
            </div>
          </div>

          <div className="sa-footer-col">
            <span>Aviation</span>
            <a href="/aviation/private-jet-charter">Private Jet Charter</a>
            <a href="/aviation/helicopter-charter">Helicopter Charter</a>
            <a href="/aviation/air-ambulance">Air Ambulance</a>
            <a href="/aviation/aircraft-advisory">Advisory &amp; Leasing</a>
            <a href="/aviation">All aviation services</a>
          </div>

          <div className="sa-footer-col">
            <span>Explore</span>
            <a href="/tirth-yatra">Tirth Yatra</a>
            <a href="/club">International Club</a>
            <a href="/global-services">Global Network</a>
            <a href="/franchise">Franchise</a>
            <a href="/insights">Insights</a>
          </div>

          <div className="sa-footer-col">
            <span>Company</span>
            <a href="/about">About us</a>
            <a href="/leadership">Leadership</a>
            <a href="/compliance">Governance</a>
            <a href="/partners">Partners</a>
            <a href="/careers">Careers</a>
            <a href="/contact">Contact</a>
          </div>

          <div className="sa-footer-col">
            <span>Reach us</span>
            <div className="sa-footer-contact">
              <div><MapPin size={15} /><span>Office No. 309, Elixa Park, Old Pune–Bangalore Highway, Shahupuri, Kolhapur, Maharashtra – 416001</span></div>
              <div><Mail size={15} /><span>Contact details shared on request through the enquiry form.</span></div>
              <div><ShieldCheck size={15} /><span>Every enquiry is handled confidentially.</span></div>
            </div>
          </div>
        </div>

        <div className="sa-footer-bottom">
          <span>© 2026 Sanatan Aviation. All rights reserved.</span>
          <span>Service availability and terms are confirmed individually.</span>
          <nav aria-label="Legal">
            <a href="/privacy-policy">Privacy</a>
            <a href="/terms">Terms</a>
            <a href="/cookie-policy">Cookies</a>
            <a href="/grievance">Grievances</a>
            <a href="/aviation">Aviation services</a>
            <a href="#home">Back to top ↑</a>
          </nav>
        </div>
      </div>
    </footer>
  );
}
