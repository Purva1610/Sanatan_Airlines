'use client';
import { LegalPage } from '../LegalPageLayout.jsx';

export default function MembershipTermsPage() {
  return (
    <LegalPage title="SkyNova Rewards — Membership Terms" lastUpdated="20 November 2026">
      <div className="legal-content">
        <p>These Membership Terms govern participation in the SkyNova Rewards frequent flyer programme operated by Sanatan Airlines Private Limited ("Sanatan Airlines", "we", "us" or "our"). By enrolling in SkyNova Rewards, you agree to these Terms in full. All members must comply with these Terms; failure to do so may result in suspension or termination of membership and forfeiture of accrued miles.</p>

        <h2>1. Eligibility and Enrolment</h2>
        <ul>
          <li>Membership is open to individuals aged 2 years and above. Members under 18 must have parental or guardian consent.</li>
          <li>Corporate entities may not enrol as individual members; see our <a href="/airline/corporate-travel">Corporate Travel</a> page for business programmes.</li>
          <li>Enrolment is free and completed via the Sanatan Airlines website or mobile application.</li>
          <li>Each individual may hold only one SkyNova Rewards account. Duplicate accounts will be merged or cancelled at our discretion.</li>
        </ul>

        <h2>2. Membership Tiers</h2>
        <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: 24 }}>
          <thead>
            <tr style={{ background: '#f0f4ff' }}>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7' }}>Tier</th>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7' }}>Qualifying Miles (Calendar Year)</th>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7' }}>Key Benefits</th>
            </tr>
          </thead>
          <tbody>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Blue</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>0 – 24,999</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Miles earning on all flights, birthday bonus miles</td></tr>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Silver</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>25,000 – 49,999</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Priority check-in, extra baggage 5 kg, lounge access (1 visit/quarter)</td></tr>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Gold</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>50,000 – 99,999</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Priority boarding, extra baggage 10 kg, unlimited lounge, upgrade vouchers</td></tr>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>Platinum</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>1,00,000+</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7' }}>All Gold benefits + dedicated account manager, guaranteed award seats, confirmed upgrades</td></tr>
          </tbody>
        </table>

        <h2>3. Earning Miles</h2>
        <ul>
          <li>Miles are credited for travel on eligible Sanatan Airlines flights and partner airline flights operated under a codeshare or interline agreement, based on the distance flown and fare class purchased.</li>
          <li>Miles earning on partner airlines, hotels, car rentals and credit cards is governed by the partner's rules; Sanatan Airlines is not responsible for miles not credited by partners.</li>
          <li>Miles must be claimed within 6 months of the qualifying activity. Retroactive claims older than 6 months will not be accepted.</li>
          <li>Miles do not constitute property of the member and have no cash value.</li>
        </ul>

        <h2>4. Redeeming Miles</h2>
        <ul>
          <li>Award tickets may be booked on eligible Sanatan Airlines flights subject to award seat availability.</li>
          <li>Award redemptions require a minimum of 7,500 miles for domestic sectors. International redemptions start at 25,000 miles one way.</li>
          <li>Taxes, surcharges and airport fees applicable to award tickets must be paid in cash at the time of redemption.</li>
          <li>Award tickets are non-refundable once booked. Changes may be permitted subject to a redeposit fee of 1,500 miles.</li>
          <li>Miles may also be redeemed for upgrades, ancillaries, hotel stays, car rentals, and gift vouchers as listed in the SkyNova Rewards catalogue.</li>
        </ul>

        <h2>5. Validity and Expiry</h2>
        <ul>
          <li>Miles are valid for 36 months from the date of credit. Any account activity (earning or redeeming at least 1 mile) resets the expiry period for all miles.</li>
          <li>Accounts with no activity for 36 consecutive months will be closed and all miles forfeited without notice.</li>
          <li>Tier status is reviewed annually on 31 January based on qualifying miles earned in the previous calendar year.</li>
        </ul>

        <h2>6. Programme Modifications and Termination</h2>
        <p>Sanatan Airlines reserves the right to modify, suspend or terminate the SkyNova Rewards programme or any aspect of it, including earning rates, redemption rates and benefits, with 30 days' notice published on our website. We are not liable for the value of miles affected by programme changes.</p>

        <h2>7. Fraud and Misuse</h2>
        <p>Any misuse of the programme, including fraudulent miles claiming, account sharing, selling or transferring miles without authorisation, will result in immediate account cancellation and forfeiture of all miles. Sanatan Airlines may pursue legal remedies for fraudulent activity.</p>

        <h2>8. Governing Law</h2>
        <p>These Membership Terms are governed by the laws of India. Disputes shall be resolved under the jurisdiction of courts in Kolhapur, Maharashtra.</p>

        <h2>9. Contact</h2>
        <p>SkyNova Rewards Member Services: <strong>skynova@sanatanairlines.com</strong> | 1800 123 4568 (Toll-free, India)</p>
      </div>
    </LegalPage>
  );
}
