'use client';
import { LegalPage } from '../LegalPageLayout.jsx';

export default function CookiePolicyPage() {
  return (
    <LegalPage title="Cookie Policy" lastUpdated="20 November 2026">
      <div className="legal-content">
        <p>This Cookie Policy explains how Sanatan Airlines Private Limited uses cookies and similar tracking technologies on our website and mobile application. It should be read alongside our <a href="/privacy-policy">Privacy Policy</a>. By continuing to use our website after reviewing this policy, you consent to our use of cookies as described below.</p>

        <h2>1. What Are Cookies?</h2>
        <p>Cookies are small text files placed on your device (computer, smartphone or tablet) when you visit a website. They allow the website to recognise your device on subsequent visits and to remember your preferences, login status and behaviour. Cookies cannot execute programs or deliver viruses to your device.</p>

        <h2>2. Types of Cookies We Use</h2>

        <h3>2.1 Strictly Necessary Cookies</h3>
        <p>These cookies are essential for the website to function. They enable core features such as security, session management and booking flow continuity. You cannot opt out of strictly necessary cookies as the website cannot work properly without them.</p>
        <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: 24 }}>
          <thead>
            <tr style={{ background: '#f0f4ff' }}>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7', fontSize: 13 }}>Cookie Name</th>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7', fontSize: 13 }}>Purpose</th>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7', fontSize: 13 }}>Duration</th>
            </tr>
          </thead>
          <tbody>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>sa_session</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>Maintains your booking session</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>Session</td></tr>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>sa_csrf</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>Prevents cross-site request forgery</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>Session</td></tr>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>sa_lang</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>Remembers your language preference</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>1 year</td></tr>
          </tbody>
        </table>

        <h3>2.2 Functional Cookies</h3>
        <p>These cookies enable enhanced functionality and personalisation such as remembering your preferred cabin class, recently viewed destinations, and login status.</p>
        <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: 24 }}>
          <thead>
            <tr style={{ background: '#f0f4ff' }}>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7', fontSize: 13 }}>Cookie Name</th>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7', fontSize: 13 }}>Purpose</th>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7', fontSize: 13 }}>Duration</th>
            </tr>
          </thead>
          <tbody>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>sa_prefs</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>Cabin class and route preferences</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>6 months</td></tr>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>sa_auth</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>Keeps you logged in to SkyNova</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>30 days</td></tr>
          </tbody>
        </table>

        <h3>2.3 Analytics Cookies</h3>
        <p>We use analytics cookies to understand how visitors interact with our website. This helps us improve page content, navigation and booking flows. Data collected is aggregated and anonymised.</p>
        <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: 24 }}>
          <thead>
            <tr style={{ background: '#f0f4ff' }}>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7', fontSize: 13 }}>Provider</th>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7', fontSize: 13 }}>Cookies</th>
              <th style={{ padding: '10px 12px', textAlign: 'left', border: '1px solid #dde3f7', fontSize: 13 }}>Duration</th>
            </tr>
          </thead>
          <tbody>
            <tr><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>Google Analytics 4</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>_ga, _ga_*, _gid</td><td style={{ padding: '8px 12px', border: '1px solid #dde3f7', fontSize: 13 }}>2 years / 24 hours</td></tr>
          </tbody>
        </table>

        <h3>2.4 Marketing & Targeting Cookies</h3>
        <p>With your consent, we place marketing cookies to show relevant advertisements on third-party platforms and to measure the effectiveness of our advertising campaigns. These cookies may track your activity across other websites.</p>

        <h2>3. How to Manage Cookies</h2>
        <p>You can control and delete cookies through your browser settings. Disabling certain cookies may affect the functionality of our website. Browser instructions for managing cookies:</p>
        <ul>
          <li><strong>Chrome:</strong> Settings → Privacy and Security → Cookies and other site data</li>
          <li><strong>Firefox:</strong> Settings → Privacy & Security → Cookies and Site Data</li>
          <li><strong>Safari:</strong> Preferences → Privacy → Manage Website Data</li>
          <li><strong>Edge:</strong> Settings → Cookies and site permissions</li>
        </ul>
        <p>You may also opt out of Google Analytics by installing the <a href="https://tools.google.com/dlpage/gaoptout" target="_blank" rel="noopener noreferrer">Google Analytics Opt-out Browser Add-on</a>.</p>

        <h2>4. Changes to This Policy</h2>
        <p>We may update this Cookie Policy as our practices or applicable regulations change. We will notify you of significant changes by displaying a notice on our website. Continued use after notice constitutes acceptance.</p>

        <h2>5. Contact Us</h2>
        <p>For questions about our use of cookies, write to <strong>legal@sanatanairlines.com</strong>.</p>
      </div>
    </LegalPage>
  );
}
