import MembershipTermsPage from '../../src/airline/legalPages/MembershipTerms';
import PageSkin from '../../src/PageSkin.jsx';

export const metadata = {
  title: 'SkyNova Rewards Membership Terms | Sanatan Airlines',
  description: 'Terms governing the SkyNova Rewards frequent flyer programme — tiers, miles earning, redemption and expiry.',
};

export default function Page() {
  return <PageSkin route="/membership-terms"><MembershipTermsPage /></PageSkin>;
}
