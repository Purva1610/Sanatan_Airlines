'use client';
import { Mail, MapPin, MessageCircle, Phone } from 'lucide-react';
import Link from 'next/link';
import { useI18n } from './i18n/I18nContext.jsx';
import LanguageSwitcher from './LanguageSwitcher.jsx';

// Social icons as inline SVG to avoid extra deps
function IconFacebook() {
  return <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.07C24 5.41 18.63 0 12 0S0 5.41 0 12.07C0 18.1 4.39 23.1 10.13 24v-8.44H7.08v-3.49h3.04V9.41c0-3.02 1.8-4.7 4.54-4.7 1.31 0 2.68.24 2.68.24v2.97h-1.51c-1.49 0-1.95.93-1.95 1.88v2.27h3.32l-.53 3.49h-2.79V24C19.61 23.1 24 18.1 24 12.07z"/></svg>;
}
function IconInstagram() {
  return <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>;
}
function IconLinkedIn() {
  return <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>;
}
function IconYoutube() {
  return <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M23.495 6.205a3.007 3.007 0 00-2.088-2.088c-1.87-.501-9.396-.501-9.396-.501s-7.507-.01-9.396.501A3.007 3.007 0 00.527 6.205a31.247 31.247 0 00-.522 5.805 31.247 31.247 0 00.522 5.783 3.007 3.007 0 002.088 2.088c1.868.502 9.396.502 9.396.502s7.506 0 9.396-.502a3.007 3.007 0 002.088-2.088 31.247 31.247 0 00.5-5.783 31.247 31.247 0 00-.5-5.805zM9.609 15.601V8.408l6.264 3.602z"/></svg>;
}
function IconWhatsApp() {
  return <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>;
}

export function AirlineFooter() {
  const { t } = useI18n();
  const year = new Date().getFullYear();
  const whatsappNumber = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER?.replace(/\D/g, '') || '';
  const phone = process.env.NEXT_PUBLIC_CONTACT_PHONE?.trim() || '';
  const phoneHref = phone.replace(/[^\d+]/g, '');
  const email = process.env.NEXT_PUBLIC_CONTACT_EMAIL?.trim() || '';

  const COLS = [
    {
      heading: t('footer.about') || 'About',
      links: [
        [t('footer.ourStory')    || 'Our Story',       '/airline/about'],
        [t('footer.about')       || 'About Us',        '/airline/about'],
        [t('footer.leadership')  || 'Leadership',      '/airline/about'],
        [t('footer.visionMission')|| 'Vision & Mission','/airline/about'],
        [t('footer.insights')    || 'Insights / Blog', '/airline/about'],
      ],
    },
    {
      heading: t('footer.services') || 'Services',
      links: [
        [t('footer.flightBooking') || 'Flight Booking', '/airline/book-flight'],
        [t('footer.charter')       || 'Charter',        '/airline/book-flight'],
        [t('footer.groupTravel')   || 'Group Travel',   '/airline/group-travel'],
        [t('footer.corporateTravel')|| 'Corporate',     '/airline/corporate-travel'],
        [t('footer.cargo')         || 'Cargo',          '/airline/cargo-services'],
        [t('footer.specialAssist') || 'Special Assist', '/airline/special-assistance'],
      ],
    },
    {
      heading: t('footer.support') || 'Support',
      links: [
        [t('footer.contactUs')    || 'Contact Us',      '/airline/contact'],
        [t('footer.faqs')         || 'FAQs',            '/airline/contact'],
        [t('footer.flightStatus') || 'Flight Status',   '/airline/flight-status'],
        [t('footer.manageBooking')|| 'Manage Booking',  '/airline/manage-booking'],
        [t('footer.grievance')    || 'Grievance',       '/grievance-redressal'],
        [t('footer.accessibility')|| 'Accessibility',   '/accessibility'],
      ],
    },
    {
      heading: t('footer.legalPolicies') || 'Legal & Policies',
      links: [
        [t('footer.privacy')             || 'Privacy Policy',           '/privacy-policy'],
        [t('footer.terms')               || 'Terms & Conditions',       '/terms-and-conditions'],
        [t('footer.cookies')             || 'Cookie Policy',            '/cookie-policy'],
        [t('footer.memberTerms')         || 'Membership Terms',         '/membership-terms'],
        [t('footer.cancellation')        || 'Cancellation & Refund',    '/cancellation-refund-policy'],
        [t('footer.franchiseDisclaimer') || 'Franchise Disclaimer',     '/franchise-disclaimer'],
        [t('footer.aviationDisclaimer')  || 'Aviation Disclaimer',      '/aviation-disclaimer'],
      ],
    },
  ];

  return (
    <footer className="p-footer" style={{
      background: 'linear-gradient(180deg, #04036b 0%, #02024a 100%)',
      color: 'rgba(215,242,250,0.75)',
      paddingTop: 72,
      fontFamily: 'var(--al-body-font, Manrope, sans-serif)',
    }}>
      <div className="al-container">

        {/* ── Brand + contact strip ── */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1.6fr 1fr 1fr',
          gap: 48,
          paddingBottom: 48,
          borderBottom: '1px solid rgba(255,255,255,0.08)',
          marginBottom: 48,
        }}>
          {/* Brand block */}
          <div>
            <Link href="/airline" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none', marginBottom: 20 }}>
              <span style={{
                width: 42, height: 42, borderRadius: '50%',
                background: '#ff4800',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontWeight: 800, fontSize: 17, color: '#fff', letterSpacing: -1,
              }}>SA</span>
              <span style={{ color: '#fff', fontSize: 14, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', lineHeight: 1.1 }}>
                SANATAN<br /><small style={{ fontSize: 9, fontWeight: 500, letterSpacing: '0.14em', opacity: 0.65 }}>AIRLINES</small>
              </span>
            </Link>

            {/* Traditional motif divider */}
            <div style={{ fontSize: 18, letterSpacing: 6, color: 'rgba(255,72,0,0.6)', marginBottom: 16 }}>
              ॐ ✦ ॐ ✦ ॐ
            </div>

            <p style={{ fontSize: 13.5, lineHeight: 1.75, color: 'rgba(215,242,250,0.65)', maxWidth: 300, marginBottom: 16 }}>
              {t('footer.tagline') || 'Connecting India and the world with warmth, reliability and world-class service.'}
            </p>

            {/* Seva | Satya | Vishwas */}
            <div style={{
              display: 'inline-block',
              fontSize: 12, fontWeight: 700, letterSpacing: '0.12em',
              color: 'rgba(255,72,0,0.9)',
              borderTop: '1px solid rgba(255,72,0,0.3)',
              paddingTop: 10, marginBottom: 20,
            }}>
              {t('footer.tagline2') || 'Seva | Satya | Vishwas'}
            </div>

            {/* Social icons */}
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              {[
                { icon: <IconFacebook />,  label: 'Facebook',  href: '#' },
                { icon: <IconInstagram />, label: 'Instagram', href: '#' },
                { icon: <IconLinkedIn />,  label: 'LinkedIn',  href: '#' },
                { icon: <IconYoutube />,   label: 'YouTube',   href: '#' },
                ...(whatsappNumber ? [{ icon: <IconWhatsApp />, label: 'WhatsApp', href: `https://wa.me/${whatsappNumber}` }] : []),
              ].map(({ icon, label, href }) => (
                <a
                  key={label} href={href} aria-label={label}
                  target={href !== '#' ? '_blank' : undefined}
                  rel={href !== '#' ? 'noopener noreferrer' : undefined}
                  style={{
                    width: 36, height: 36, borderRadius: '50%',
                    background: 'rgba(255,255,255,0.08)',
                    border: '1px solid rgba(255,255,255,0.15)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: 'rgba(215,242,250,0.75)',
                    textDecoration: 'none',
                    transition: 'background 0.15s, color 0.15s',
                  }}
                  onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(255,72,0,0.3)'; e.currentTarget.style.color = '#fff'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.background = 'rgba(255,255,255,0.08)'; e.currentTarget.style.color = 'rgba(215,242,250,0.75)'; }}
                >
                  {icon}
                </a>
              ))}
            </div>
          </div>

          {/* Contact block */}
          <div>
            <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', marginBottom: 20 }}>
              Contact
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                <span style={{ fontSize: 16, flexShrink: 0, marginTop: 1 }}><MapPin size={16}/></span>
                <span style={{ fontSize: 13, lineHeight: 1.65, color: 'rgba(215,242,250,0.65)' }}>
                  {t('footer.address') || 'Office No. 309, Elixa Park, Old Pune–Bangalore Highway, Shahupuri, Kolhapur, Maharashtra – 416001'}
                </span>
              </div>
              {phone && <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                <span style={{ fontSize: 16, flexShrink: 0 }}><Phone size={20}/></span>
                <a href={`tel:${phoneHref}`} style={{ fontSize: 14, fontWeight: 700, color: 'rgba(215,242,250,0.9)', textDecoration: 'none' }}>
                  {phone}
                </a>
              </div>}
              {email && <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                <span style={{ fontSize: 16, flexShrink: 0 }}><Mail size={16}/></span>
                <a href={`mailto:${email}`} style={{ fontSize: 13, color: 'rgba(215,242,250,0.75)', textDecoration: 'none', wordBreak: 'break-all' }}>
                  {email}
                </a>
              </div>}
              {whatsappNumber && <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                <span style={{ fontSize: 16, flexShrink: 0 }}><MessageCircle size={20}/></span>
                <a href={`https://wa.me/${whatsappNumber}`} target="_blank" rel="noopener noreferrer" style={{ fontSize: 13, color: '#25D366', textDecoration: 'none', fontWeight: 600 }}>
                  WhatsApp
                </a>
              </div>}
            </div>
          </div>

          {/* Language switcher */}
          <div>
            <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', marginBottom: 20 }}>
              {t('nav.language') || 'Language'}
            </div>
            <LanguageSwitcher />
            <p style={{ fontSize: 11.5, color: 'rgba(215,242,250,0.4)', marginTop: 12, lineHeight: 1.6 }}>
              Content available in 14 Indian languages. Select your preferred language above.
            </p>
          </div>
        </div>

        {/* ── Four-column link grid ── */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: 32,
          paddingBottom: 56,
          borderBottom: '1px solid rgba(255,255,255,0.08)',
        }}>
          {COLS.map((col) => (
            <div key={col.heading}>
              <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', marginBottom: 18 }}>
                {col.heading}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                {col.links.map(([label, href]) => (
                  <Link
                    key={href + label}
                    href={href}
                    style={{ fontSize: 13.5, color: 'rgba(215,242,250,0.65)', textDecoration: 'none', padding: '5px 0', transition: 'color 0.15s' }}
                    onMouseEnter={(e) => { e.currentTarget.style.color = '#fff'; }}
                    onMouseLeave={(e) => { e.currentTarget.style.color = 'rgba(215,242,250,0.65)'; }}
                  >
                    {label}
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* ── Bottom bar ── */}
        <div style={{
          padding: '24px 0',
          display: 'flex', flexWrap: 'wrap',
          gap: 16, alignItems: 'center', justifyContent: 'space-between',
        }}>
          <div>
            <div style={{ fontSize: 12.5, color: 'rgba(255,255,255,0.35)' }}>
              © {year} Sanatan Airlines Pvt. Ltd. — {t('footer.legal') || 'Operated subject to DGCA and IATA regulations.'}
            </div>
          </div>
          <nav aria-label="Legal quick links" style={{ display: 'flex', flexWrap: 'wrap', gap: 16 }}>
            {[
              ['Privacy', '/privacy-policy'],
              ['Terms', '/terms-and-conditions'],
              ['Cookies', '/cookie-policy'],
              ['Grievance', '/grievance-redressal'],
              ['Accessibility', '/accessibility'],
            ].map(([label, href]) => (
              <Link key={href} href={href} style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)', textDecoration: 'none' }}
                onMouseEnter={(e) => { e.currentTarget.style.color = 'rgba(255,255,255,0.7)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.color = 'rgba(255,255,255,0.35)'; }}
              >
                {label}
              </Link>
            ))}
          </nav>
        </div>
      </div>

      {/* Responsive overrides */}
      <style>{`
        @media (max-width: 900px) {
          .al-footer-brand-grid { grid-template-columns: 1fr 1fr !important; }
          .al-footer-link-grid  { grid-template-columns: 1fr 1fr !important; }
        }
        @media (max-width: 540px) {
          .al-footer-brand-grid { grid-template-columns: 1fr !important; }
          .al-footer-link-grid  { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </footer>
  );
}
