'use client';
import { LegalPage } from '../LegalPageLayout.jsx';

export default function TermsAndConditionsPage() {
  return (
    <LegalPage title="Terms & Conditions" lastUpdated="20 November 2026">
      <div className="legal-content">
        <p>These Terms & Conditions ("Terms") govern your use of Sanatan Airlines' website, mobile application, and all services provided by Sanatan Airlines Private Limited ("Sanatan Airlines", "we", "us" or "our"). By booking a flight, accessing our website or using our services, you agree to these Terms in full. If you do not agree, please discontinue use immediately.</p>

        <h2>1. Definitions</h2>
        <ul>
          <li><strong>"Passenger"</strong> means any person holding a valid ticket issued by Sanatan Airlines.</li>
          <li><strong>"Ticket"</strong> means the electronic or paper document, including e-ticket confirmation, entitling the holder to travel on a specified flight.</li>
          <li><strong>"Booking"</strong> means a confirmed reservation for one or more passengers on one or more Sanatan Airlines flights.</li>
          <li><strong>"Conditions of Carriage"</strong> means Sanatan Airlines' General Conditions of Carriage, available at the time of booking and forming part of these Terms.</li>
        </ul>

        <h2>2. Acceptance of Terms</h2>
        <p>These Terms apply to every transaction on our website and every flight operated by or on behalf of Sanatan Airlines. By completing a booking or check-in, you confirm you have read, understood and agreed to these Terms and to our Conditions of Carriage, Privacy Policy and applicable fare rules.</p>

        <h2>3. Bookings and Payments</h2>
        <h3>3.1 Making a Booking</h3>
        <ul>
          <li>All bookings are subject to seat availability and applicable fares at the time of booking.</li>
          <li>Fares are not guaranteed until full payment is received and a booking reference number is issued.</li>
          <li>You are responsible for ensuring all passenger details (name, date of birth, passport number) are accurate. Name corrections post-issuance may attract a fee.</li>
        </ul>
        <h3>3.2 Payment</h3>
        <ul>
          <li>All prices are displayed in Indian Rupees (INR) unless otherwise stated. Applicable taxes and surcharges are added at checkout.</li>
          <li>Payment is processed via PCI-DSS certified gateways. Sanatan Airlines does not store full card details.</li>
          <li>Failure to complete payment within the hold period will result in automatic cancellation of the reservation.</li>
        </ul>

        <h2>4. Ticket Validity and Fare Rules</h2>
        <ul>
          <li>Each ticket is valid for the specific flight(s), date(s), route(s) and passenger named on it.</li>
          <li>Tickets are non-transferable. Only the named passenger may travel on the ticket.</li>
          <li>Fare rules, including change fees, cancellation charges and validity periods, are displayed at the time of booking and form part of your contract of carriage.</li>
        </ul>

        <h2>5. Changes and Cancellations</h2>
        <ul>
          <li>Changes to bookings are permitted subject to availability and applicable change fees per the purchased fare family.</li>
          <li>Cancellations are subject to the refund policy applicable to your fare type. See our <a href="/cancellation-refund-policy">Cancellation & Refund Policy</a> for full details.</li>
          <li>Sanatan Airlines reserves the right to cancel or reschedule flights for operational, safety or regulatory reasons. In such cases, passengers are entitled to rebooking or a refund per DGCA regulations.</li>
        </ul>

        <h2>6. Check-in and Boarding</h2>
        <ul>
          <li>Passengers must complete check-in and be at the boarding gate by the minimum check-in times published for each route.</li>
          <li>Failure to present valid identification or travel documents will result in denied boarding without refund.</li>
          <li>Sanatan Airlines may deny boarding to any passenger who appears to be under the influence of alcohol or drugs, or whose conduct poses a risk to safety.</li>
        </ul>

        <h2>7. Baggage</h2>
        <p>Baggage allowances, restrictions and excess baggage fees are set out in our <a href="/airline/baggage">Baggage Information</a> page and form part of these Terms. Items prohibited by DGCA, IATA Dangerous Goods Regulations or applicable law may not be carried.</p>

        <h2>8. Conduct on Board</h2>
        <ul>
          <li>Passengers must comply with all crew instructions and applicable aviation regulations during flight.</li>
          <li>Disruptive, threatening or violent behaviour will result in removal from the aircraft and may lead to permanent travel ban and criminal prosecution.</li>
          <li>Smoking, including e-cigarettes, is strictly prohibited on all Sanatan Airlines flights and in all airport facilities.</li>
        </ul>

        <h2>9. Limitation of Liability</h2>
        <p>Sanatan Airlines' liability for passenger death, injury, delay, baggage loss and damage is governed by the Carriage by Air Act, 1972 (incorporating the Montreal Convention) and our Conditions of Carriage. Where permitted by law, liability for delay is limited to INR 7,500 per passenger per sector unless a higher limit is established. We are not liable for consequential or indirect losses.</p>

        <h2>10. Force Majeure</h2>
        <p>Sanatan Airlines is not liable for failure to perform any obligation where such failure results from circumstances beyond our reasonable control, including but not limited to natural disasters, acts of terrorism, government actions, strikes, pandemics, air traffic control restrictions or severe weather.</p>

        <h2>11. Intellectual Property</h2>
        <p>All content on this website, including text, graphics, logos, images and software, is the property of Sanatan Airlines or its licensors and is protected under applicable intellectual property laws. No content may be reproduced, distributed or used commercially without our prior written consent.</p>

        <h2>12. Governing Law & Dispute Resolution</h2>
        <p>These Terms are governed by the laws of India. Any dispute arising out of or in connection with these Terms shall first be referred to our Grievance Officer. Unresolved disputes shall be subject to the exclusive jurisdiction of the courts at Kolhapur, Maharashtra, India.</p>

        <h2>13. Amendments</h2>
        <p>Sanatan Airlines may amend these Terms at any time. The current version is published on our website. Continued use of our services after publication of amended Terms constitutes acceptance.</p>

        <h2>14. Contact</h2>
        <p>Sanatan Airlines Private Limited, Office No. 309, Elixa Park, Kolhapur – 416001. Email: <strong>legal@sanatanairlines.com</strong>. Phone: 1800 123 4567.</p>
      </div>
    </LegalPage>
  );
}
