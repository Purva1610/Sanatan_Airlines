export default function SiteFooter() {
  return (
    <footer className="site-footer" id="policies">
      <div className="footer-main">
        <div className="footer-brand-column">
          <a className="brand footer-brand" href="/" aria-label="Sanatan Airlines home">
            <span className="brand-mark" aria-hidden="true"><span>S</span></span>
            <span className="brand-name">SANATAN<span>AIRLINES</span></span>
          </a>
          <p>Personal coordination across aviation, international travel and global services.</p>
          <span className="footer-location-note">Office No. 309, Elixa Park, Old Pune–Bangalore Highway, Shahupuri, Kolhapur, Maharashtra – 416001<br />Phone and email details pending approval.</span>
        </div>
        <div className="footer-links-column"><span>EXPLORE</span><a href="/tirth-yatra">Tirth Yatra</a><a href="/#aviation">Aviation</a><a href="/#club">International Club</a><a href="/#global-services">Global Services</a><a href="/franchise">Franchise</a></div>
        <div className="footer-links-column"><span>THE COMPANY</span><a href="/about">About us</a><a href="/leadership">Leadership</a><a href="/compliance">Governance & compliance</a><a href="/partners">Partners & credentials</a><a href="/partners/enquiry">Partner enquiry</a><a href="/careers">Careers</a><a href="/insights">Insights</a><a href="/contact">Contact</a></div>
        <div className="footer-links-column"><span>POLICIES</span><a href="/privacy-policy">Privacy policy</a><a href="/terms">Terms of use</a><a href="/cookie-policy">Cookie policy</a><a href="/accessibility">Accessibility</a><a href="/grievance">Grievance / complaints</a></div>
      </div>
      <div className="footer-bottom"><span>© 2026 Sanatan Airlines. All rights reserved.</span><span>Service availability and terms are confirmed individually.</span><a href="/#home">Back to top ↑</a></div>
    </footer>
  );
}
