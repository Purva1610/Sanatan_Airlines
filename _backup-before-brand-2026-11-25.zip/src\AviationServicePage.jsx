'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';
import {
  ArrowRight, ArrowUpRight, Check, Clock, ClipboardCheck, Compass, Globe2,
  HeartHandshake, Lock, MessagesSquare, ShieldAlert, ShieldCheck, UsersRound,
} from 'lucide-react';
import { LeadFeedback, LeadHoneypot, useLeadCapture } from './useLeadCapture.js';
import { SiteFooter, SiteHeader } from './SiteChrome.jsx';
import { FaqStructuredData } from './SeoStructuredData.jsx';

export const DISCLAIMER = 'All services are subject to route, aircraft availability, and confirmation by licensed operators. Sanatan Aviation coordinates enquiries and does not own or operate aircraft.';

const aviationNav = [
  ['Aviation Services', '/aviation'],
  ['Private Jet', '/aviation/private-jet-charter'],
  ['Helicopter', '/aviation/helicopter-charter'],
  ['Air Ambulance', '/aviation/air-ambulance'],
  ['Advisory & Leasing', '/aviation/aircraft-advisory'],
  ['Insights', '/insights'],
];

const serviceIndex = [
  ['01', 'Private Jet', 'private-jet-charter'],
  ['02', 'Helicopter', 'helicopter-charter'],
  ['03', 'Air Ambulance', 'air-ambulance'],
  ['04', 'Advisory & Leasing', 'aircraft-advisory'],
];

const serviceNames = {
  'private-jet-charter': 'Private Jet Charter',
  'helicopter-charter': 'Helicopter Charter',
  'air-ambulance': 'Air Ambulance & Medical Flight',
  'aircraft-advisory': 'Aircraft Advisory & Leasing',
};

const commonFields = [
  { name: 'name', label: 'Name', required: true, autoComplete: 'name', placeholder: 'Your full name' },
  { name: 'phone', label: 'Mobile / WhatsApp', type: 'tel', required: true, autoComplete: 'tel', defaultValue: '+91 ', pattern: '\\+?[0-9][0-9\\s.\\x2d]{6,19}', title: 'Enter an international phone number, including country code', placeholder: '+91 98765 43210' },
  { name: 'email', label: 'Email', type: 'email', required: true, autoComplete: 'email', placeholder: 'you@example.com', wide: true },
];

const services = {
  'private-jet-charter': {
    number: '01',
    name: 'Private Jet Charter',
    nameSerif: 'Coordination',
    eyebrow: 'Aviation services · Private jet',
    sub: 'Seamless, confidential private jet travel for business, family and special journeys — coordinated through licensed operators.',
    image: '/images/sa-hero-jet.jpg',
    imageAlt: 'A private jet flying above Indian hills and a river at golden hour',
    imagePosition: 'center',
    short: 'Private jet coordination',
    formType: 'jet_charter',
    formService: 'Private jet charter',
    introTitle: 'Privacy, time and care — arranged with clarity.',
    introCopy: [
      'A private jet journey is less about the aircraft and more about what it returns to you: time, privacy and the freedom to travel on your own terms.',
      'Sanatan Aviation receives your brief and coordinates with appropriately licensed operators. Route suitability, aircraft availability and terms are confirmed for your specific journey before anything is agreed.',
    ],
    benefits: [
      { icon: Lock, title: 'Confidential by design', copy: 'Itineraries, passenger details and preferences are handled discreetly and shared only where necessary.' },
      { icon: Clock, title: 'Time returned to you', copy: 'Private terminals, flexible departure windows and onward coordination that respects your schedule.' },
      { icon: UsersRound, title: 'Comfort for every generation', copy: 'Cabin, catering and assistance considerations for elders, children and long journeys.' },
      { icon: MessagesSquare, title: 'One accountable contact', copy: 'A dedicated coordinator stays with your enquiry from first brief to departure day.' },
    ],
    useCases: [
      ['Business travel', 'Schedules that protect meetings, rest and preparation time.'],
      ['Family journeys', 'Space, privacy and pacing that work for every generation.'],
      ['Pilgrimage travel', 'Respectful coordination for yatra and darshan itineraries.'],
      ['Medical travel', 'Non-emergency journeys planned around comfort and continuity.'],
      ['Celebrations & events', 'Movement for weddings, gatherings and milestone occasions.'],
      ['Multi-city itineraries', 'A single coordinated thread across several stops.'],
    ],
    band: {
      image: '/images/sa-about-family.jpg',
      alt: 'A family walking together through a private lounge toward their aircraft at sunset',
      quote: 'For many families, the journey begins long before the flight.',
      copy: 'We plan around the people travelling — their pace, their needs, their reasons. That is the Sanatan way of service.',
    },
    steps: [
      ['Share the brief', 'Route, dates, passengers and priorities through a confidential enquiry.'],
      ['Personal review', 'A coordinator clarifies details, flexibility and anything that matters to your family.'],
      ['Operator options', 'Suitable licensed operators are approached; availability and suitability are confirmed case by case.'],
      ['Confirm with clarity', 'Operator details, terms and next steps are shared before any commitment.'],
    ],
    fields: [
      { name: 'origin', label: 'Departure city or airport', required: true, placeholder: 'e.g. Mumbai' },
      { name: 'destination', label: 'Destination city or airport', required: true, placeholder: 'e.g. London' },
      { name: 'tripType', label: 'Trip type', type: 'select', required: true, options: ['One-way', 'Return', 'Multi-city'] },
      { name: 'travelDate', label: 'Travel date', type: 'date', required: true },
      { name: 'passengers', label: 'Passengers', type: 'number', min: 1, required: true, placeholder: 'Number of travellers' },
      { name: 'flexible', label: 'My dates are flexible', type: 'checkbox' },
      { name: 'message', label: 'Route, dates and message', type: 'textarea', wide: true, placeholder: 'Luggage, catering, accessibility needs or anything we should know' },
    ],
    faqs: [
      ['Does sending this form confirm a flight?', 'No. It is a confidential enquiry only. Availability, operator details, pricing and terms are confirmed individually before any commitment.'],
      ['Will I know which operator is flying?', 'Yes. Where a journey is arranged, the licensed operating partner and applicable details are shared with you before confirmation.'],
      ['Can you coordinate pilgrimage or family travel?', 'Yes. Pilgrimage, family and multi-generation journeys are a core part of our work, subject to route, aircraft availability and operator confirmation.'],
      ['What information helps the coordinator most?', 'Origin, destination, travel dates and flexibility, passenger count, luggage needs and any comfort or accessibility considerations.'],
    ],
    related: ['helicopter-charter', 'air-ambulance', 'aircraft-advisory'],
  },
  'helicopter-charter': {
    number: '02',
    name: 'Helicopter Charter',
    nameSerif: 'Coordination',
    eyebrow: 'Aviation services · Helicopter',
    sub: 'Fast, flexible helicopter transfers and scenic flights coordinated with licensed operators for remote access, pilgrimage and urgent travel.',
    image: '/images/sa-helicopter-himalaya.jpg',
    imageAlt: 'A helicopter flying above forested Himalayan foothills at golden hour',
    imagePosition: 'center',
    short: 'Helicopter coordination',
    formType: 'helicopter',
    formService: 'Helicopter charter',
    introTitle: 'When the road ends, coordination begins.',
    introCopy: [
      'Helicopters bring distant shrines, hill towns, estates and project sites within reach of a single morning.',
      'Sanatan Aviation coordinates your request with licensed operators. Landing permissions, weather windows, daylight limitations and site suitability are reviewed individually — never assumed.',
    ],
    benefits: [
      { icon: Globe2, title: 'Access beyond the road', copy: 'Point-to-point transfers where terrain or distance makes surface travel impractical, subject to site suitability.' },
      { icon: HeartHandshake, title: 'Yatra support with care', copy: 'Coordinated transfers for pilgrimage itineraries, with landing permissions reviewed for each location.' },
      { icon: Clock, title: 'Short-haul, time-sensitive', copy: 'Rapid movement for meetings, events or urgent non-emergency needs within operating limits.' },
      { icon: ShieldCheck, title: 'Operational diligence', copy: 'Weather, daylight and local permissions are reviewed with the operator before feasibility is confirmed.' },
    ],
    useCases: [
      ['Pilgrimage yatra', 'Hill shrines and darshan itineraries, coordinated with respect.'],
      ['Remote & hill access', 'Estates, retreats and sites away from main roads.'],
      ['VIP & event transfers', 'Discreet short-haul movement for guests and principals.'],
      ['Corporate short-haul', 'Time-critical movement between cities or facilities.'],
      ['Scenic journeys', 'Considered aerial experiences over remarkable landscapes.'],
      ['Urgent non-emergency travel', 'Where time matters and roads do not cooperate.'],
    ],
    band: {
      image: '/images/sa-insight-yatra.jpg',
      alt: 'A family with luggage at riverside temple steps at sunrise',
      quote: 'A yatra is measured in devotion, not distance.',
      copy: 'We coordinate the practical details so families can keep their attention where it belongs — on the journey itself.',
    },
    steps: [
      ['Share pickup and drop', 'Locations, timing and the purpose of your journey.'],
      ['Clarify the essentials', 'Passenger count, luggage and any special requirements.'],
      ['Review feasibility', 'Landing permissions, weather windows and operator suitability are assessed.'],
      ['Confirm terms', 'Any viable arrangement, operator details and terms are shared before commitment.'],
    ],
    fields: [
      { name: 'pickup', label: 'Pickup location', required: true, placeholder: 'City, helipad or address' },
      { name: 'dropoff', label: 'Drop-off location', required: true, placeholder: 'City, helipad or address' },
      { name: 'dateTime', label: 'Preferred date and time', type: 'datetime-local', required: true },
      { name: 'passengers', label: 'Passengers', type: 'number', min: 1, required: true, placeholder: 'Number of travellers' },
      { name: 'purpose', label: 'Purpose of travel', type: 'select', required: true, options: ['Pilgrimage yatra', 'Remote or hill access', 'VIP / event transfer', 'Corporate travel', 'Scenic journey', 'Other'] },
      { name: 'message', label: 'Route, dates and message', type: 'textarea', wide: true, placeholder: 'Luggage, landing context, flexibility or anything we should know' },
    ],
    faqs: [
      ['Can any location be used as a landing site?', 'No. Every landing location is reviewed individually. Permissions, surface conditions, surrounding obstructions and local rules must be confirmed before a site can be considered.'],
      ['Is weather a factor?', 'Yes. Helicopter operations depend on weather and daylight. A coordinator will discuss feasible windows with the operator for your dates.'],
      ['Does this confirm a helicopter for my date?', 'No. This is an enquiry only. Operator availability, feasibility and terms are confirmed separately.'],
      ['What about pilgrimage support?', 'We coordinate transfers around yatra itineraries, subject to landing permissions, weather and licensed operator availability.'],
    ],
    related: ['private-jet-charter', 'air-ambulance', 'aircraft-advisory'],
  },
  'air-ambulance': {
    number: '03',
    name: 'Air Ambulance & Medical Flight',
    nameSerif: 'Coordination',
    eyebrow: 'Aviation services · Medical flights',
    sub: 'Urgent medical evacuation and inter-hospital transfer coordination through licensed air ambulance operators — handled with care, confidentiality and urgency.',
    image: '/images/sa-air-ambulance-dawn.jpg',
    imageAlt: 'A medical crew beside a plain white air ambulance jet at dawn',
    imagePosition: 'center',
    short: 'Medical flight coordination',
    formType: 'air_ambulance',
    formService: 'Air ambulance',
    emergency: {
      title: 'This website is not an emergency dispatch channel.',
      copy: 'If someone needs urgent medical help now, call your local emergency services first. Do not wait for a website response.',
    },
    introTitle: 'Calm coordination when every hour matters.',
    introCopy: [
      'Medical flights are arranged around a patient, a clinical team and a receiving hospital — not around a schedule.',
      'Sanatan Aviation coordinates non-emergency and time-sensitive enquiries with licensed air ambulance operators. Clinical suitability, aircraft configuration, medical escort requirements and ground transfers are confirmed by the relevant medical and operating teams before any service proceeds.',
    ],
    benefits: [
      { icon: Clock, title: 'Round-the-clock enquiry line', copy: 'A coordinator can receive time-sensitive requests at any hour. Emergencies must go to local emergency services.' },
      { icon: ShieldCheck, title: 'Medical configuration', copy: 'Stretcher systems, oxygen and escort requirements are matched with operator capability and clinical advice.' },
      { icon: UsersRound, title: 'Family accompaniment', copy: 'Where the cabin configuration allows, seating and updates for accompanying family are coordinated with care.' },
      { icon: HeartHandshake, title: 'Ground transfer alignment', copy: 'Ambulance and hospital-side timing are aligned where possible so the handover is calm and clear.' },
    ],
    useCases: [
      ['Inter-hospital transfers', 'Movement between treating facilities with continuity of care in mind.'],
      ['Medical repatriation', 'Returning home for continued treatment, coordinated respectfully.'],
      ['Planned treatment travel', 'Non-emergency journeys to specialist centres.'],
      ['Post-treatment return', 'A considered return journey once clinical teams agree.'],
      ['Remote-area coordination', 'Access from locations where ground transfer is impractical.'],
      ['Family updates', 'A single point of contact for accompanying family members.'],
    ],
    band: {
      image: '/images/sa-insight-yatra.jpg',
      alt: 'A quiet sunrise over riverside steps, suggesting calm and care',
      quote: 'Care is measured in presence, not speed alone.',
      copy: 'Behind every medical flight is a family waiting for clarity. Our role is to coordinate calmly and tell the truth at every step.',
    },
    steps: [
      ['Share the essentials', 'Origin, destination, patient condition category and timing — high-level details only.'],
      ['Engage operators', 'Licensed air ambulance operators are approached with the route and clinical requirements.'],
      ['Confirm suitability', 'Medical team, aircraft configuration and availability are confirmed together.'],
      ['Align the handover', 'Ground transfer and receiving-team timing are coordinated before the flight proceeds.'],
    ],
    fields: [
      { name: 'origin', label: 'Origin city or hospital', required: true, placeholder: 'e.g. Kolhapur' },
      { name: 'destination', label: 'Destination city or hospital', required: true, placeholder: 'e.g. Mumbai' },
      { name: 'urgency', label: 'Timing', type: 'select', required: true, options: ['Planned transfer', 'Time-sensitive, not an emergency'] },
      { name: 'conditionCategory', label: 'Patient condition category', type: 'select', required: true, options: ['Stable transfer enquiry', 'Requires mobility assistance', 'Requires medical supervision', 'Prefer to discuss with a clinician'] },
      { name: 'groundAmbulance', label: 'Ground ambulance required?', type: 'select', required: true, options: ['Yes', 'No', 'Not sure'] },
      { name: 'attendants', label: 'Accompanying family / attendants', type: 'number', min: 0, required: true, placeholder: 'Number of people' },
      { name: 'message', label: 'Route, dates and message', type: 'textarea', wide: true, placeholder: 'Share high-level details only. Do not include medical records or sensitive clinical information.' },
    ],
    faqs: [
      ['Can I use this form in a medical emergency?', 'No. This is not an emergency dispatch channel. Call your local emergency services immediately. This form is for non-emergency and time-sensitive planning enquiries.'],
      ['Does submitting confirm a medical flight?', 'No. Clinical suitability, operator capability, aircraft availability and terms must all be confirmed first.'],
      ['What medical information should I share?', 'Only the high-level details requested. A relevant medical team can advise what else is needed through an appropriate channel. Please do not send records through this form.'],
      ['Can family travel with the patient?', 'Where the aircraft configuration allows, family accompaniment can be coordinated. This is confirmed case by case with the operator and medical team.'],
    ],
    related: ['private-jet-charter', 'helicopter-charter', 'aircraft-advisory'],
  },
  'aircraft-advisory': {
    number: '04',
    name: 'Aircraft Advisory & Leasing',
    nameSerif: 'Coordination',
    eyebrow: 'Aviation services · Advisory & leasing',
    sub: 'Independent advisory and leasing coordination for individuals and organisations seeking aircraft solutions through verified partners.',
    image: '/images/sa-jet-tarmac.jpg',
    imageAlt: 'A business jet parked on the tarmac at golden hour',
    imagePosition: 'center',
    short: 'Advisory & leasing',
    formType: 'aircraft_advisory',
    formService: 'Aircraft advisory & leasing',
    introTitle: 'An independent view before a long-term decision.',
    introCopy: [
      'Acquiring, selling or leasing an aircraft is a long-term commitment. The value of good advice is measured in the questions asked early.',
      'Sanatan Aviation provides coordination and advisory support — helping you define requirements, understand options and engage verified third-party partners. We do not own, buy or sell aircraft as principal, and we do not operate aircraft.',
    ],
    benefits: [
      { icon: Compass, title: 'Independent advisory', copy: 'Needs assessment and aircraft category guidance, without bias toward a single manufacturer or operator.' },
      { icon: ClipboardCheck, title: 'Acquisition & sale support', copy: 'Process coordination and introductions through verified partners, subject to independent due diligence.' },
      { icon: Globe2, title: 'Leasing coordination', copy: 'Short- and long-term lease enquiries aligned with intended use, region and operational plan.' },
      { icon: HeartHandshake, title: 'Long-term liaison', copy: 'Documentation review coordination, delivery planning and continued support after the decision.' },
    ],
    useCases: [
      ['First aircraft purchase', 'A structured, unhurried first conversation.'],
      ['Fleet planning', 'Define categories, missions and operating assumptions.'],
      ['Sale of an aircraft', 'Coordinated introductions to verified partners.'],
      ['Lease vs. buy', 'Understand trade-offs before committing capital.'],
      ['Due diligence support', 'Independent technical, legal and tax advice remains essential.'],
      ['Long-term charter alternatives', 'Compare access models before choosing ownership.'],
    ],
    band: {
      image: '/images/sa-hero-jet.jpg',
      alt: 'A private jet above Indian hills at golden hour',
      quote: 'Good advice is measured in clarity, not in a quick signature.',
      copy: 'Our role is coordination: define the requirement, verify the counterparties and let independent specialists advise on the transaction itself.',
    },
    steps: [
      ['Define the requirement', 'Mission, region, timeline and the outcome you need.'],
      ['Scope the advisory', 'Agree what coordination and introductions are appropriate.'],
      ['Verify partners', 'Engage verified third-party specialists for technical, legal and financial review.'],
      ['Support the decision', 'Coordinate documents, timelines and next steps without acting as principal.'],
    ],
    fields: [
      { name: 'aircraftType', label: 'Aircraft type or category', type: 'select', required: true, options: ['Light jet', 'Midsize jet', 'Large cabin jet', 'Turboprop', 'Helicopter', 'To be discussed'] },
      { name: 'transaction', label: 'Requirement', type: 'select', required: true, options: ['Purchase', 'Sale', 'Lease', 'Advisory'] },
      { name: 'region', label: 'Preferred region', placeholder: 'e.g. India, Gulf, Europe' },
      { name: 'timeline', label: 'Timeline', type: 'select', options: ['As soon as practical', 'Within 3 months', 'Within 6 months', 'Exploring options'] },
      { name: 'intendedUse', label: 'Intended use', type: 'textarea', wide: true, required: true, placeholder: 'Typical missions, routes and operating context' },
      { name: 'message', label: 'Message', type: 'textarea', wide: true, placeholder: 'Anything else that would help the first conversation' },
    ],
    faqs: [
      ['Does Sanatan Aviation own or operate aircraft?', 'No. Sanatan Aviation coordinates enquiries and advisory work with verified partners. We do not own, buy or sell aircraft as principal, and we do not operate aircraft.'],
      ['Is this a valuation or legal advice?', 'No. Any valuation, legal, tax or technical review is provided by appropriately qualified independent specialists. Our role is coordination.'],
      ['Can I enquire about selling an aircraft?', 'Yes. Select “Sale” and include basic details. A coordinator will explain how the process can be supported.'],
      ['What happens after I submit?', 'A coordinator reviews your requirement and responds personally to arrange a first conversation. No obligation is implied.'],
    ],
    related: ['private-jet-charter', 'helicopter-charter', 'air-ambulance'],
  },
};

function Field({ field }) {
  const id = field.name;
  if (field.type === 'checkbox') {
    return (
      <label className="sa-av-checkbox" htmlFor={id}>
        <input id={id} name={field.name} type="checkbox" />
        <span>{field.label}</span>
      </label>
    );
  }
  return (
    <label className={`sa-field${field.wide ? ' sa-field-wide' : ''}`} htmlFor={id}>
      <span>{field.label}{field.required && <b> *</b>}</span>
      {field.type === 'select' ? (
        <select id={id} name={field.name} required={field.required} defaultValue={field.defaultValue || ''}>
          <option value="">Select an option</option>
          {field.options.map((option) => <option key={option}>{option}</option>)}
        </select>
      ) : field.type === 'textarea' ? (
        <textarea id={id} name={field.name} required={field.required} rows="4" placeholder={field.placeholder || ''} />
      ) : (
        <input
          id={id}
          name={field.name}
          type={field.type || 'text'}
          required={field.required}
          min={field.min}
          defaultValue={field.defaultValue}
          pattern={field.pattern}
          title={field.title}
          autoComplete={field.autoComplete}
          placeholder={field.placeholder || ''}
        />
      )}
    </label>
  );
}

function ServiceForm({ service }) {
  const leadCapture = useLeadCapture(service.formType);

  return (
    <form
      className="sa-av-form sa-form-card"
      {...leadCapture.formProps}
      aria-label={`${service.name} enquiry — request confidential coordination`}
    >
      <div className="sa-form-head">
        <strong>Request confidential coordination</strong>
        <span>Confidential</span>
      </div>
      {service.emergency && (
        <div className="sa-av-form-alert" role="note">
          <ShieldAlert size={18} aria-hidden="true" />
          <p><strong>{service.emergency.title}</strong> {service.emergency.copy}</p>
        </div>
      )}
      <LeadHoneypot />
      <div className="sa-form-grid">
        <label className="sa-field sa-field-wide" htmlFor={`preferred-${service.formType}`}>
          <span>Preferred service <b>*</b></span>
          <select id={`preferred-${service.formType}`} name="preferredService" required defaultValue={service.formService}>
            <option>Private jet charter</option>
            <option>Helicopter charter</option>
            <option>Air ambulance</option>
            <option>Aircraft advisory &amp; leasing</option>
          </select>
        </label>
        {service.fields.map((field) => <Field key={field.name} field={field} />)}
        {commonFields.map((field) => <Field key={field.name} field={field} />)}
      </div>
      <label className="sa-consent">
        <input name="consent" type="checkbox" required />
        <span>I agree to be contacted about this enquiry. View our <a href="/privacy-policy">Privacy Policy</a>.</span>
      </label>
      <button className="sa-btn sa-btn-primary sa-form-submit" type="submit" disabled={leadCapture.isSubmitting}>
        {leadCapture.isSubmitting ? 'Sending…' : 'Request Confidential Coordination'} <ArrowUpRight size={16} />
      </button>
      <LeadFeedback status={leadCapture.status} />
      <p className="sa-form-hint">
        No pricing, availability or booking is confirmed by submitting this form. Every request is reviewed individually.
      </p>
      <p className="sa-av-form-disclaimer">{DISCLAIMER}</p>
    </form>
  );
}

export default function AviationServicePage({ service: serviceKey }) {
  const service = services[serviceKey] || services['private-jet-charter'];
  const [stickyVisible, setStickyVisible] = useState(false);
  const [formInView, setFormInView] = useState(false);
  const [footerInView, setFooterInView] = useState(false);

  useEffect(() => {
    const onScroll = () => setStickyVisible(window.scrollY > 640);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const target = document.getElementById('enquiry');
    if (!target || !('IntersectionObserver' in window)) return undefined;
    const observer = new IntersectionObserver(([entry]) => setFormInView(entry.isIntersecting), { threshold: 0.12 });
    observer.observe(target);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const footer = document.querySelector('.sa-footer');
    if (!footer || !('IntersectionObserver' in window)) return undefined;
    const observer = new IntersectionObserver(([entry]) => setFooterInView(entry.isIntersecting));
    observer.observe(footer);
    return () => observer.disconnect();
  }, []);

  const focusEnquiry = () => {
    document.getElementById('enquiry')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    window.setTimeout(() => {
      document.querySelector('.sa-av-form input[name="name"]')?.focus({ preventScroll: true });
    }, 750);
  };

  return (
    <div className="sa-page sa-av" id="home">
      <SiteHeader links={aviationNav} ctaHref="#enquiry" ctaLabel="Request Coordination" />

      <main id="main">
        <section className="sa-av-hero">
          <div className="sa-av-hero-media">
            <Image
              src={service.image}
              alt={service.imageAlt}
              fill
              sizes="100vw"
              preload
              style={{ objectPosition: service.imagePosition }}
            />
          </div>
          <div className="sa-container sa-av-hero-inner">
            <nav className="sa-av-crumbs" aria-label="Breadcrumb">
              <a href="/">Home</a><span aria-hidden="true">/</span>
              <a href="/aviation">Aviation services</a><span aria-hidden="true">/</span>
              <span aria-current="page">{service.name}</span>
            </nav>
            <span className="sa-hero-kicker">{service.eyebrow}</span>
            <h1>{service.name} <em>{service.nameSerif}</em></h1>
            <p className="sa-av-hero-sub">{service.sub}</p>
            <div className="sa-av-hero-actions">
              <a className="sa-btn sa-btn-primary" href="#enquiry">Request Confidential Coordination <ArrowUpRight size={16} /></a>
              <button className="sa-btn sa-btn-ghost" type="button" onClick={focusEnquiry}>Speak to a Coordinator <MessagesSquare size={16} /></button>
            </div>
            <div className="sa-hero-trust sa-av-trust">
              <span className="sa-trust-chip"><ShieldCheck size={15} /> Licensed operators</span>
              <span className="sa-trust-chip"><Lock size={15} /> Confidential coordination</span>
              <span className="sa-trust-chip"><HeartHandshake size={15} /> Trust &amp; seva</span>
            </div>
          </div>
        </section>

        <div className="sa-av-disclaimer-bar" role="note">
          <div className="sa-container">
            <ShieldCheck size={17} aria-hidden="true" />
            <p>{DISCLAIMER}</p>
          </div>
        </div>

        <nav className="sa-av-switcher" aria-label="Aviation services">
          <div className="sa-container">
            {serviceIndex.map(([number, label, slug]) => (
              <a key={slug} href={`/aviation/${slug}`} className={slug === serviceKey ? 'is-current' : undefined} aria-current={slug === serviceKey ? 'page' : undefined}>
                <small>{number}</small>{label}
              </a>
            ))}
          </div>
        </nav>

        <section className="sa-section sa-section-white" id="service">
          <div className="sa-container">
            <div className="sa-av-intro">
              <div className="sa-av-intro-head">
                <span className="sa-eyebrow">The service</span>
                <h2>{service.introTitle}</h2>
                {service.introCopy.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
              </div>
            </div>
            <div className="sa-av-benefits">
              {service.benefits.map((benefit) => {
                const Icon = benefit.icon;
                return (
                  <article className="sa-av-benefit" key={benefit.title}>
                    <span className="sa-av-benefit-icon"><Icon size={21} strokeWidth={1.5} /></span>
                    <h3>{benefit.title}</h3>
                    <p>{benefit.copy}</p>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        <section className="sa-section sa-section-ivory" id="use-cases">
          <div className="sa-container">
            <div className="sa-av-section-head">
              <span className="sa-eyebrow">Where this helps</span>
              <h2>Considered journeys, <em className="sa-serif">every reason.</em></h2>
              <p>Every enquiry is reviewed individually. The situations below simply describe where coordinated aviation support most often begins.</p>
            </div>
            <div className="sa-av-use-grid">
              {service.useCases.map(([title, copy], index) => (
                <article className="sa-av-use" key={title}>
                  <span>{String(index + 1).padStart(2, '0')}</span>
                  <h3>{title}</h3>
                  <p>{copy}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="sa-av-band">
          <div className="sa-av-band-media">
            <Image src={service.band.image} alt={service.band.alt} fill sizes="(max-width: 900px) 100vw, 50vw" />
          </div>
          <div className="sa-av-band-copy">
            <span className="sa-eyebrow">The Sanatan approach</span>
            <blockquote>{service.band.quote}</blockquote>
            <p>{service.band.copy}</p>
            <div className="sa-why-values">
              <span>Vishwas</span><span>Seva</span><span>Dharma</span>
            </div>
          </div>
        </section>

        <section className="sa-section sa-section-white" id="process">
          <div className="sa-container">
            <div className="sa-av-section-head">
              <span className="sa-eyebrow">How coordination works</span>
              <h2>From first question <em className="sa-serif">to informed next steps.</em></h2>
              <p>Four clear stages. No pressure, no hidden assumptions — only what can genuinely be confirmed.</p>
            </div>
            <ol className="sa-av-steps">
              {service.steps.map(([title, copy], index) => (
                <li key={title}>
                  <span className="sa-av-step-number">{String(index + 1).padStart(2, '0')}</span>
                  <h3>{title}</h3>
                  <p>{copy}</p>
                </li>
              ))}
            </ol>
            {serviceKey === 'aircraft-advisory' && (
              <p className="sa-av-advisory-note">
                <ShieldCheck size={16} aria-hidden="true" />
                Sanatan Aviation provides coordination and advisory services only. We do not own, buy or sell aircraft as principal, and do not operate aircraft. Transactions involve verified third-party partners and remain subject to independent legal, tax and technical advice.
              </p>
            )}
          </div>
        </section>

        <section className="sa-section sa-section-ivory sa-av-enquiry" id="enquiry">
          <div className="sa-container">
            <div className="sa-av-enquiry-grid">
              <div className="sa-av-enquiry-copy">
                <span className="sa-eyebrow">Your enquiry</span>
                <h2>Request a <em className="sa-serif">confidential</em> conversation.</h2>
                <p>
                  Share a few details and a coordinator will respond personally. There is no obligation,
                  no automated pricing and no pressure — just honest answers about what may be possible.
                </p>
                <div className="sa-consult-points">
                  <div className="sa-consult-point"><Check size={16} /> A real person, not a call queue</div>
                  <div className="sa-consult-point"><Check size={16} /> Options confirmed with licensed operators</div>
                  <div className="sa-consult-point"><Check size={16} /> Every enquiry handled confidentially</div>
                </div>
                <div className="sa-av-enquiry-note">
                  <ShieldCheck size={17} aria-hidden="true" />
                  <p>{DISCLAIMER}</p>
                </div>
                <button className="sa-btn sa-btn-dark sa-av-speak" type="button" onClick={focusEnquiry}>
                  Speak to a Coordinator <ArrowRight size={16} />
                </button>
              </div>
              <ServiceForm service={service} />
            </div>
          </div>
        </section>

        <section className="sa-section sa-section-white" id="faqs">
          <div className="sa-container sa-av-faq-wrap">
            <div className="sa-av-section-head">
              <span className="sa-eyebrow">Good to know</span>
              <h2>Before you <em className="sa-serif">enquire.</em></h2>
            </div>
            <div className="sa-av-faqs">
              {service.faqs.map(([question, answer]) => (
                <details key={question}>
                  <summary>{question}<span aria-hidden="true">+</span></summary>
                  <p>{answer}</p>
                </details>
              ))}
            </div>
          </div>
          <FaqStructuredData items={service.faqs} />
        </section>

        <section className="sa-section sa-section-navy sa-av-related">
          <div className="sa-container">
            <div className="sa-av-section-head">
              <span className="sa-eyebrow">Continue exploring</span>
              <h2>Other aviation <em className="sa-serif">services.</em></h2>
            </div>
            <div className="sa-av-related-grid">
              {service.related.map((slug) => (
                <a key={slug} href={`/aviation/${slug}`}>
                  <span>Aviation service</span>
                  <h3>{serviceNames[slug]}</h3>
                  <ArrowUpRight size={18} />
                </a>
              ))}
            </div>
            <p className="sa-av-related-foot">
              All aviation services are coordinated with licensed operators and confirmed individually.
            </p>
          </div>
        </section>
      </main>

      <div className={`sa-av-sticky${stickyVisible && !formInView && !footerInView ? ' is-visible' : ''}`}>
        <span className="sa-av-sticky-label">{service.short}<small>Confidential coordination</small></span>
        <a className="sa-btn sa-btn-primary" href="#enquiry">Request Coordination <ArrowUpRight size={15} /></a>
      </div>

      <SiteFooter />
    </div>
  );
}
